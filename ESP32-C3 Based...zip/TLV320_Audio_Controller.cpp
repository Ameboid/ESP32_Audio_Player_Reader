#include "Wire.h"
class TLV3204{ 
// Specifically for the TLV3204AIC3204 series from Texas Instruments.
//It could work with others, but that would be pushing it
    const static int DEVICE_ADDRESS = 0x18;

    bool readToggle = false, read_ = false, selectedChannelAGC = false;


    enum KEYWORDS {
    READ,/*!Reads back the value of a given regeister when called to a method 
    that supports it*/

    //0,4,3-0(PLL)
    //0,4,1-0(CODEC_CLKIN)
    //0,25,2-0(CDIV_CLKIN)
    MCLK/*!Set the selected clock divider to use the Master Clock(MCLK) from I2S.
    Can be done on PLL Input Clock, CODEC_CLKIN, CDIV_CLKIN*/,

    //0,4,3-0(PLL)
    //0,4,1-0(CODEC_CLKIN)
    //0,25,2-0(CDIV_CLKIN)
    BCLK/*!Set the selected clock divider to use the Bit Clock(BCLK) from I2S.
    Can be done on PLL Input Clock, CODEC_CLKIN, CDIV_CLKIN*/,

    //0,4,3-0(PLL)
    //0,4,1-0(CODEC_CLKIN)
    //0,32,6-5(Second BCLK),4-3(Second WCLK),2-1(ADC_WCLK),0(Second DIN)
    GPIO/*!Set the selected clock divider to use the GPIO pin as the source. Can
    be done on PLL Input Clock, CODEC_CLKIN, the selection of the Secondary BCLK,
    Secondary WCLK, ADC_WCLK, or Secondary DIN,*/,

    //0,4,3-0(PLL)
    //0,4,1-0(CODEC_CLKIN)
    //0,25,2-0(CDIV_CLKIN)
    DIN/*!Set the selected clock divider to use the DIN pin as the source. Can be
    done on PLL Input Clock, CDIV_CLKIN*/,

    //0,4,1-0(CODEC_CLKIN)
    //0,25,2-0(CDIV_CLKIN)
    PLL/*!Set the selected clock divider to use the PLL divider clock as source. 
    can be done on CODEC_CLKIN, CDIV_CLKIN*/,

    //0,25,2-0(CDIV_CLKIN)
    DAC_CLK/*!Set the selected clock divider to use the Clock from the DAC. Can 
    be done on CDIV_CLKIN*/,

    //0,25,2-0(CDIV_CLKIN)
    ADC_CLK/*!Set the selected clock divider to use the Clock from the ADC. Can 
    be done on CDIV_CLKIN*/,

    //0,25,2-0(CDIV_CLKIN)
    DAC_MOD_CLK/*!Set the selected clock divider to use the generated DAC 
    Modulator Clock. Can be done on CDIV_CLKIN*/,

    //0,25,2-0(CDIV_CLKIN)
    ADC_MOD_CLK/*!Set the selected clock divider to use the generated ADC 
    Modulator Clock. Can be done on CDIV_CLKIN*/,

    //0,32,6-5(Second BCLK),4-3(Second WCLK),2-1(ADC_WCLK),0(Second DIN)
    SCLK/*!Set the Multiplexer to use the SCLK pin as either the Secondary 
    Bit Clock, Secondary Word Clock, ADC Word Clock, or Secondary Data
    Input. One pin can be assigned to only one Multiplexer*/,

    //0,32,6-5(Second BCLK),4-3(Second WCLK),2-1(ADC_WCLK),0(Second DIN)
    MISO/*!Set the Multiplexer to use the SCLK pin as either the Secondary 
    Bit Clock, Secondary Word Clock, or ADC Word Clock. One pin can be 
    assigned to only one Multiplexer*/,

    //0,32,6-5(Second BCLK),4-3(Second WCLK),2-1(ADC_WCLK),0(Second DIN)
    DOUT/*!Set the Multiplexer to use the SCLK pin as either the Secondary 
    Bit Clock or Secondary Word Clock. One pin can be assigned to only one 
    Multiplexer*/,

    //0,27,7-6(Audio Interface Setting)
    I2S/*!Stands for Inter-integrated Sound, said as I squared C. Used for the 
    selection of the Audio Interface.*/,

    //0,27,7-6(Audio Interface Setting)
    DSP/*!Stands for Digital Sound Processing. Used for the selection of the
    Audio Interface*/,

    //0,27,7-6(Audio Interface Setting)
    RJF/*!Right JustiFied Mode. Used for the selection of the Audio Interface*/,

    //0,27,7-6(Audio Interface Setting)
    LJF/*!Left JustiFied Mode. Used for the selection of the Audio Interface*/,

    DISABLE/*!Disables the multifunction capability of a pins control register*/,

    //0,52,5-2(GPIO)
    //0,54,2-1(DIN/MFP1)
    //0,56,2-1(SCLK/MFP3)
    MISC_APPLICATION/*!Refers to a function of a multiplexer that has multiple 
    different possibilities given one choice. Explained in the description of the
    called method. Can be done on GPIO, DIN/MFP1, and SCLK/MFP3*/,

    //0,52,5-2(GPIO)
    //0,54,2-1(DIN/MFP1)
    //0,56,2-1(SCLK/MFP3)
    INPUT_/*!Set the selected pin to function as a General Purpose Input(GPI). 
    Can be done on GPIO, DIN/MFP1, and SCLK/MFP3*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    OUTPUT_/*!Set the selected pin to function as a General Purpose Output(GPO).
    Can be done on GPIO, DOUT/MFP2, and MISO/MFP4*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    INT1/*!Set the selected pin to function as the output for the INT1 Signal to
    the host. Can be done on GPIO, DOUT/MFP2, and MISO/MFP4*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    INT2/*!Set the selected pin to function as the output for the INT2 Signal to
    the host. Can be done on GPIO, DOUT/MFP2, and MISO/MFP4*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    CLKOUT/*!Set the selected pin to function as the Auxillary Clock Out. Can be 
    done on GPIO, DOUT/MFP2, and MISO/MFP4*/,
    
    //0,53,3-1(DOUT/MFP2)
    PRIME_DOUT/*!Sets DOUT/MFP2 to be the Primary Data Out for the Audio Interface.*/,

    //0,52,5-2(GPIO)
    ADC_WCLK_IN/*!Set the selected pin to function as the ADC Word Clock for primary
    Audio Interface. Can be done on GPIO*/,

    //0,55,4-1(MISO/MFP4)
    ADC_WCLK_OUT/*!Set the selected pin to function as the ADC Word Clock Output. Can
    be done on MISO/MFP4*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    SECOND_BCLK/*!Set the selected pin to function as the Secondary Bit-Clock for
    the secnond Audio Interface. Can be done on GPIO and DOUT/MFP2*/,

    //0,52,5-2(GPIO)
    //0,53,3-1(DOUT/MFP2)
    //0,55,4-1(MISO/MFP4)
    SECOND_WCLK/*!Set the selected pin to function as the Secondary Word-Clock for
    the second Audio Interface. Can be done on GPIO and DOUT/MFP2*/,

    //0,55,4-1(MISO/MFP4)
    SECOND_DOUT/*!Set the selected pin to function as the Secondary Data Output for
    the Audio Interface. Can be done on MISO*/,

    //0,52,5-2(GPIO)
    DIGITAL_MIC_CLK/*!Set the selected pin to function as the Clock for a Digital 
    Microphone. Can be done on GPIO*/,

    //0,55,4-1(MISO/MFP4)
    SPI_MODE/*!Enables the SPI functionality for a pin. Can be done on MISO/MFP4*/,

    HPL/*!High Power Left Keyword*/, HPR/*!High Power Right Keyword*/, 
    LOL/*!Low Output Left Keyword*/, LOR/*!Low Output Right Keyword*/, 
    NONE/*!No routing is currently selected.*/,
    PTM_R4 = 0, PTM_R3 = 100, PTM_R2 = 182, PTM_R1 = 255, //Pulse-Time Modulation
  };
  enum HEADSET_TYPES {
    NO_HEADSET, STEREO_HEADSET, STEREO_PLUS_CELLULAR_HEADSET
  };
  enum ERROR_CODES {
    VALUE, /*!A value was written of which did not fall in the range of specified*/
    MULTIPLE_SELECT /*!Tends to occur when doing routing, it happens when a signal 
    is routed to more than one place*/
  };
    void writeData(int pageNum, int regNum, int data, int length = 8, 
    int startBit = 0){
      if(timeOut(true) == true) return;
      Wire.write(0);// Select Register 0 for the Page Select
      Wire.write(pageNum);// Go to selected Page
      Wire.write(0);// Select the first Register, Page Select
      Wire.endTransmission();
      // Reading from the register for Bit Splicing
      Wire.beginTransmission(DEVICE_ADDRESS);
      Wire.write(0);// Write Condition
      Wire.write(regNum);// Select a Register
      Wire.beginTransmission(DEVICE_ADDRESS);// Repeated Start Condition
      Wire.write(1);// Read Condition
      int readData = Wire.read();// Read data from TLV3204
      Wire.write(1);// Master NACK
      Wire.endTransmission();// Stop

      /*****BIT SPLICING*****/
      int tempData[3];
      tempData[0] = readData << (length + startBit);// MSB Section
      tempData[1] = ~(~readData << (8 - length - startBit));// LSB Section
      // Recombobulation of the split data plus new data
      tempData[2] = (((tempData[0] << (length + startBit)) + data) << length) 
      + tempData[1];

      Wire.beginTransmission(DEVICE_ADDRESS);// Begin communication
      Wire.write(0);// Write condition
      Wire.write(regNum);// The Register of a Page to select
      Wire.write(tempData[2]);// Writes the compiled data
      Wire.endTransmission();
    }

    // NOTE: startBit is from the LSB of the entire set, so on the final register
    // NOTE: regNum goes from least to greatest(LSB)
    void writeData(int pageNum, int regNum[], int data, int length,
    int startBit = 0){
      if(timeOut(true) == true) return;
      Wire.write(0);// Select Register 0 for the Page Select
      Wire.write(pageNum);// Go to selected Page
      Wire.write(0);// Select the first Register, Page Select
      Wire.endTransmission();
      int readData;
      for(int i = 0; i < sizeof(regNum); i++){
        Wire.beginTransmission(DEVICE_ADDRESS);
        Wire.write(0);// Write Condition
        Wire.write(regNum[i]);// Select a Register
        Wire.beginTransmission(DEVICE_ADDRESS);// Repeated Start Condition
        Wire.write(1);// Read Condition
        // Shift the data over by 8 bits each time. Bellow starts at the end 
        //of the data.
        readData = readData << (length - 8 * (sizeof(regNum) - i));
        readData += Wire.read();// Read data from TLV3204
        Wire.write(1);// Master NACK
        Wire.endTransmission();// Stop
      }
      int bitSpliceData;
      int tempData[sizeof(regNum) + 1][3];// Create an array of the data of which
      //contains the read data, the data to write, and the combined data
      for(int i = 0; i < sizeof(readData); i++){
        bitSpliceData;
      }
      //TODO: See if this will report the amount of bits a member contains
      //It doesn't. boo hoo. But 
      /*while (n) { 
          count++; 
          n >>= 1; 
        } 
      does...
      */
      while(sizeof(data) != sizeof(readData))
      for(int i = 0; i < sizeof(regNum); i++){
        // Seperates 8 bits for each member to write to the register. Starts
        //at the first register
        tempData[i][0] = readData << (length - 8 * (sizeof(regNum) - i));
        // Formats data for splicing
        tempData[i][1] = data << (length - 8 * (sizeof(regNum) - 1));
      }
    }

    int readData(int pageNum, int regNum, int length, int startBit = 0){
      Wire.write(0);// Select Register 0 for the Page Select
      Wire.write(pageNum);// Go to selected Page
      Wire.write(0);// Select the first Register, Page Select
      Wire.endTransmission();
      // Reading from the register for Bit Splicing
      Wire.beginTransmission(DEVICE_ADDRESS);
      Wire.write(0);// Write Condition
      Wire.write(regNum);// Select a Register
      Wire.beginTransmission(DEVICE_ADDRESS);// Repeated Start Condition
      Wire.write(1);// Read Condition
      int readData = Wire.read();// Read data from TLV3204
      Wire.write(1);// Master NACK
      Wire.endTransmission();// Stop
      int tempData;
      tempData = readData << startBit;
      tempData = ~readData << (7 - length - startBit);
      return tempData;
    }
    // NOTE: regNum goes from greatest to least(MSB)
    int  readData(int pageNum, int regNum[], int length, int startBit = 0){
      Wire.write(0);// Select Register 0 for the Page Select
      Wire.write(pageNum);// Go to selected Page
      Wire.write(0);// Select the first Register, Page Select
      Wire.endTransmission();
      int readData;
      for(int i = 0; i < sizeof(regNum); i++){
        Wire.beginTransmission(DEVICE_ADDRESS);
        Wire.write(0);// Write Condition
        Wire.write(regNum[i]);// Select a Register
        Wire.beginTransmission(DEVICE_ADDRESS);// Repeated Start Condition
        Wire.write(1);// Read Condition
        readData += Wire.read();// Read data from TLV3204
        Wire.write(1);// Master NACK
        Wire.endTransmission();// Stop
      }
      //Removes the leading zeros
      readData = readData << startBit;
      int tempData;
      //Isolates one bit, and adds it to the flipped data
      for(int i = 0; i < sizeof(regNum) * 8; i++){ 
        //                                        Subtracts the stuff before the 
        //          Contains single bit, but      desired bit from the data that
        //          has stuff before              has the bit
        tempData += (readData << (length - i)) - (readData << (length + 1 - i));
      }
      //Removes the precceding zeros
      readData = tempData << (sizeof(regNum) * 8 - length);
      return readData; //Final data, as one very long integer.
    }

    bool toggleable(int pageNum, int regNum, int start, bool read_ = false){
      Wire.write(0);// Select Register 0 for the Page Select
      Wire.write(pageNum);// Go to selected Page
      Wire.write(0);// Select the first Register, Page Select
      Wire.endTransmission();
      // Reading from the register for Bit Splicing
      Wire.beginTransmission(DEVICE_ADDRESS);
      Wire.write(0);// Write Condition
      Wire.write(regNum);// Select a Register
      Wire.beginTransmission(DEVICE_ADDRESS);// Repeated Start Condition
      Wire.write(1);// Read Condition
      int readData = Wire.read();// Read data from TLV3204
      Wire.write(1);// Master NACK
      Wire.endTransmission();// Stop

      int tempData = readData;
      readData = readData << start;
      if(read_){
        bool value = (readData ? 1 : 0);
        return value;
      }else{
        readData = readData & 0b00000000;
        tempData = tempData | readData;
        // Writes the new value, changing the toggle value
        Wire.beginTransmission(DEVICE_ADDRESS);// Begin communication
        Wire.write(0);// Write condition
        Wire.write(regNum);// The Register of a Page to select
        Wire.write(tempData);// Writes the compiled data
        Wire.endTransmission();
      }
    }
    bool timeOut(bool beginTransmission = false){
      if(beginTransmission = true){
        Wire.beginTransmission(DEVICE_ADDRESS);
        Wire.write(0);// Pulls line low for Write
        delay(1); // Waits for 1ms to see if the TLV3204 has responded by pulling the 
        //bus low. If it doesn't, reports an error. Nothing is written to the TLV3204,
        //this is only to ensure it exists.
        // Time out for 1 second
        int timeOut = millis();
        while(Wire.read() == 1){
          if(millis() - timeOut >= 1000) return true;
        }
        return false;
      }else{
        delay(1); // Waits for 1ms to see if the TLV3204 has responded by pulling the 
        //bus low. If it doesn't, reports an error. Nothing is written to the TLV3204,
        //this is only to ensure it exists.
        // Time out for 1 second
        int timeOut = millis();
        while(Wire.read() == 1){
          if(millis() - timeOut >= 1000) return true;
        }
        return false;
      }
    }

    /*
      Some things to know:
        - AGC: Automatic Gain Control
        - PLL: Phase Locked Loop
        - PGA: Programmable Gain Amplifiers
        - DRC: Dynamic Range Compression
    */
    /*!
      READ ONLY REGISTERS:
      These are the registers of which are read only, and are flag registers that 
      can be implemented, if I want...
      - 36 *1 is active Power; 1 AGC Gain is max; 0 PGA Gain is not equal*
        - Left ADC PGA 
        - Left ADC Power 
        - Left AGC Gain(Self Clear)
        - N/A
        - Right ADC PGA 
        - Right ADC Power
        - Right AGC Gain(Self Clear)
        - N/A
      - 37 *1 is powered Up*
        - Left DAC Power
        - LOL(Line Output Left, Speakers/Amp) Power
        - HPL(High Power Left, Headphone) Power
        - N/A
        - Right DAC Power
        - LOR(Line Output Right, Speakers/Amp) Power
        - HPR(High Power Right, Heaphone) Power
        - N/A
      - 38 *0 is error*
        - N/A x3
        - Left DAC PGA Gain
        - N/A x3
        - Right DAC PGA Gain
      - 42 *Sticky Flag Registers; Clear on read; 1 is error; Since last read*
        - Left ADC Overflow
        - Right DAC Overflow
        - N/A x2
        - Left ADC Overflow
        - Right ADC Overflow
        - N/A x2
      - 43 *1 is Overflow; At time of reading*
        - Left DAC Overflow
        - Right DAC Overflow
        - N/A x2
        - Left ADC Overflow
        - Right ADC Overflow
        - N/A x2
      - 44 *1 is error/detection; DRC normal is below*
        - HPL Over Current
        - HPR Over Current
        - Headset Button Press
        - Left Channel DRC Signal Threshold
        - Right Channel DRC Signal Threshold
        - N/A 2x
      - 45 
        - N/A
        - Left AGC Noise Threshold
        - Right AGC Noise Threshold
        - N/A x2
        - Left ADC DC Measurement Avaliable

    /*
      EQUATIONS/THINGS TO KNOW:
        ADC_FS = CODEC_CLKIN / (NADC x MADC x AOSR)
        ADC_MOD_CLK = CODEC_CLKIN / (NADC x MADC)
        DAC_FS = CODEC_CLKIN / (NDAC x MDAC x DOSR)
        DAC_MOD_CLK = CODEC_CLKIN / (NDAC x MDAC)
        CODEC_CLKIN     50MHz                 137MHz when NDAC is even, NADC is even
                                              112MHz when NDAC is even, NADC is odd
                                              110MHz when NDAC is odd, NADC is even
                                              110MHz when NDAC is odd, NADC is odd
        ADC_CLK         25MHz                               55.296MHz
        ADC_MOD_CLK   6.758MHz                              6.758MHz
        ADC_FS        0.192MHz                              0.192MHz
        DAC_CLK         25MHz                               55.296MHz
        DAC_MOD_CLK   6.758MHz                              6.758MHz   
                      4.2MHz when Class-D 
                      Mode Headphone is used
        DAC_FS        0.192MHz                              0.192MHz
        BDIV_CLKIN      25MHz                              55.296MHz
        CDIV_CLKIN      50MHz                         112MHz when M is odd
                                                      137MHz when M is even
    */
////************************** METHODS **************************\\\\
    /*!
      @breif  Creates a new TLV3204 class
    */
    TLV3204_Controller();

    /*!
     @breif  Hopefully you see this, but here's a long one. This library was made
     by one person, and all features may or may not be present. Anyways, there are
     some terms of which are good to know:
       - AGC: Automatic Gain Control
       - PLL: Phase Locked Loop
       - PGA: Programmable Gain Amplifiers
       - DRC: Dynamic Range Compression
       - ADC: Analog to Digital Converter
       - DAC: Digital to Analog Converter
       - DSP: Digital Signal Processing
       - PTM: Pulse-Time Modulation
     These are some of the abbreviations to know, but for more information go to:
     https://www.ti.com/lit/ml/slaa557/slaa557.pdf?ts=1726675121068 For register
     descriptions and application diagrams
     https://www.ti.com/lit/ds/symlink/tlv3204320aic3204.pdf?ts=1726735376116 For a
     brief overview of the TLV3204320AIC3204, of which this Library is designed for.
     @param  dataPin   SDA Pin of the TLV3204 connected to the Microcontroller. SPI
     functionality has yet to be implemented.
     @param  clockPin  SCL Pin of the TLV3204 connected to the Microcontroller. SPI
     functionality has yet to be implemented.
   */
   void TLV3204(int dataPin, int clockPin){
     Wire.begin(dataPin, clockPin);
     if(this -> timeOut(true) == true) return; // Calls the function to determine
     //if the TLV3204 has timed out its communication.
     // Pull bus high to stop the communication
     Wire.write(1);
     Wire.endTransmission();
   }
   /*!
     @breif       Writes audio data to the TLV3204
     @param data  The data to be sent, 24 bit integer
   */
   void writeAudio(int data){}
   /*!
     @breif   Reads the audio data from the TLV3204
     @return  The current data avliable from the ADC. 24 bit integer
   */
   int readAudio(){}



   /*!
     @breif  Performs a software defined reset
   */
   //0,1,0
   void softReset(){ this -> toggleable(0,1,7); }

   /*!
    @breif  Allows the toggleable registers to be read when added onto the 
    toggle function.
   */
   void readToggleRegister(){ readToggle = true; }

   /*!
     @breif        The Reference Power Up Configuration
     @param  time  Settings are: slow(0), 40ms, 80ms, and 120ms.
     @param  type  true to power up when Analog Blocks are powered up, false to
     force a power up of Ref
   */
   //1,123,2-0
   void refPowerUp(int time, bool type){
    if(time < 0 || time > 120 || time % 40 != 0) throw VALUE;
    if(type) this -> writeData(1,123,time/40,3,0);// Power up when Analog Blocks powered up
    else this -> writeData(1,123,(time/40)+3,3,0);// Force power up of Reference
   }

   ////************************** CLOCK SETTINGS **************************\\\\
   /*!
     @breif        Sets the divider value of PLL.  If all are 0(10000 for D), 
     then PLL is powered down. Set one to 0(10000 for D) to read back the value
     @param  rou   The Greek Letter that looks like a P, 1-7. Default 1
     @param  R     Divider R Value, 1-4. Default 1
     @param  J     Divider J Value, 4-63. Default 4
     @param  D     Divider D Value, 0-9999. Default 0
     @return       The value of the requested divider
   */
   //rou 0,5,6-4
   //R 0,5,3-0
   //J 0,6,5-0
   //D 0,7(5-0)-8(7-0)
   int clockDividerPLL(int rou, int R, int J, int D){
    if(rou == R == J == 0 && D = 10000 && !this -> toggleable(0,5,7,6,true)){
      this -> toggleable(0,5,7,6);// Shut down PLL
    }else if(rou == 0) return this -> readData(0,5,3,4);
    else if(R  ==  0) return this -> readData(0,5,3);
    else if(J  ==  0) return this -> readData(0,6,5);
    else if(D  == 10000) return this -> readData(0,{7,8},14);
    else{
      if(this -> toggleable(0,5,7,6,true)) this -> toggleable(0,5,7,6);
      this -> writeData(0,5,rou,3,4);
      this -> writeData(0,5, R, 3);
      this -> writeData(0,6, J, 5);
      this -> writeData(0,{7,8},D,14);
    }
   }
   /*!
    @breif              Controls the PLL Input Clock. MCLK, BCLK, GPIO, or DIN
    can be selected from the KEYWORDS enum
    @param  clockSource The clock source
   */
   //0,4,3-2
   int inputClockPLL(KEYWORDS clockSource){
    if(clockSource == READ){
      switch(this -> readData(0,4,2,2)){
        case 0: return MCLK;
        case 1: return BCLK;
        case 2: return GPIO;
        case 3: return DIN;
      }
    }
    int data;
    switch(clockSource){
      case MCLK: data = 0b00; break;
      case BCLK: data = 0b01; break;
      case GPIO: data = 0b10; break;
      case DIN:  data = 0b11; break;
    }
    this -> writeData(0,4,data,2,2);
   }
   /*!
    @breif              Controls the CODEC_CLKIN. MCLK, BCLK, GPIO, or PLL
    can be selected from the KEYWORDS enum
    @param  clockSource The clock source
   */
   //0,4,1-0
   int codecClockIn(KEYWORDS clockSource){
    if(clockSource == READ){
      switch(this -> readData(0,4,2)){
        case 0: return MCLK;
        case 1: return BCLK;
        case 2: return GPIO;
        case 3: return PLL;
      }
    }
    int data;
    switch(clockSource){
      case MCLK: data = 0b00; break;
      case BCLK: data = 0b01; break;
      case GPIO: data = 0b10; break;
      case PLL:  data = 0b11; break;
    }
    this -> writeData(0,4,data,2);
   }


   /*!
     @breif            NADC and NDAC Clock Setting values. NADC is the ADC 
     Clock Divider, NDAC is the DAC Clock Divider. Set a value to zero to power
     down that divider.
     @param  analogIn  Value for NADC Clock Divider
     @param  analogOut Value for NDAC Clock Divider. When powered down, ADC_CLK 
     is the same as DAC_CLK
     @return           Requested value of a Clock Divider. Do not set anything 
     to read back the value
   */
   //Power 0,11,7(DAC), 0,18,7(ADC)
   //DAC 0,11,6-0
   //ADC 0,18,6-0
   int clockSettingN(int analogIn = 130, int analogOut = 130){
    ///** NADC **\\\
    // Disables Divider
    if(analogIn == 0 && !this -> toggleable(0,18,7,true)) this -> toggleable(0,18,7);
    // Read Instance
    else if(analogIn == 130) return this -> readData(0,18,7);
    // Write Instance, but in order to prevent when the Divider is off and 
    //it wants to be off, prevents it from defaulting to a possible set
    else if(analogIn != 0 && analogIn != 130){
      // Check divider is off. If so, get that s**t back on
      if(this -> toggleable(0,18,7,true)) this -> toggleable(0,18,7);
      this -> writeData(0,18,analogIn,7);
    }
    ///** NDAC **\\\
    // Disables Divider
    if(analogOut == 0 && !this -> toggleable(0,11,7,true)) this -> toggleable(0,11,7);
    // Read Instance
    else if(analogOut == 130) return this -> readData(0,11,7);
    // Write Instance, but in order to prevent when the Divider is off and 
    //it wants to be off, prevents it from defaulting to a possible set
    else if(analogIn != 0 && analogIn != 130){
      // Check divider is off. If so, get that s**t back on
      if(this -> toggleable(0,11,7,true)) this -> toggleable(0,11,7);
      this -> writeData(0,11,analogIn,7);
    }
   }


   /*!
     @breif            MADC and MDAC Clock Setting values. MADC is the ADC Mod
     Clock and MDAC is the DAC Mod Clock. Set a value to zero to power down that
     divider
     @param  analogIn  Value for MADC Clock Divider
     @param  analogOut Value for MDAC Clock Divider. When powered down, 
     ADC_MOD_CLK is the same as DAC_MOD_CLK
     @return           Requested value of a Clock Divider. Do not set anything 
     to read back the value
   */
   //Power 0,12,7(DAC), 0,19,7(ADC)
   //DAC 0,12,6-0
   //ADC 0,19,6-0
   int clockSettingM(int analogIn = 130, int analogOut = 130){
    ///*! MADC **\\\
    // Disables Divider
    if(analogIn == 0 && !this -> toggleable(0,19,7,true)) this -> toggleable(0,19,7);
    // Read Instance
    else if(analogIn == 130) return this -> readData(0,19,7);
    // Write Instance, but in order to prevent when the Divider is off and 
    //it wants to be off, prevents it from defaulting to a possible set
    else if(analogIn != 0 && analogIn != 130){
      // Check divider is off. If so, get that s**t back on
      if(this -> toggleable(0,19,7,true)) this -> toggleable(0,19,7);
      this -> writeData(0,19,analogIn,7);
    }
    ///*! MDAC **\\\
    // Disables Divider
    if(analogOut == 0 && !this -> toggleable(0,12,7,true)) this -> toggleable(0,12,7);
    // Read Instance
    else if(analogOut == 130) return this -> readData(0,12,7);
    // Write Instance, but in order to prevent when the Divider is off and 
    //it wants to be off, prevents it from defaulting to a possible set
    else if(analogIn != 0 && analogIn != 130){
      // Check divider is off. If so, get that s**t back on
      if(this -> toggleable(0,12,7,true)) this -> toggleable(0,12,7);
      this -> writeData(0,12,analogIn,7);
    }
   }


   /*!
     @breif          Clock Out M divider Value. Set to 0 to power the divider
     down.
     @param  value   The value of which to set to
     @return         Requested value. Do not set anything to read back the value
   */
   //Power 0,26,7
   //0,26,6-0
   int clockOutM(int value = 130){
    // Disable Divider
    if(value == 0 && !this -> toggleable(0,26,7,true)) this -> toggleable(0,26,7);
    // Read Instance
    else if(value == 130) return this -> readData(0,26,7);
    // Write Instance to prevent the first if statement from being false 
    //because the divider is already off
    else if(value != 0 && value != 130){
      if(this -> toggleable(0,26,7,true)) this -> toggleable(0,26,7);
      this -> writeData(0,26,value,7);
    }
   }


   /*!
     @breif          Offsets the Audio Data In by an amount of BCLKs
     @param  offset  How many BCLKs to offset the data in by.
   */
   //0,28,7-0
   void dataInOffset(int offset){
    if(offset < 0 || offset > 255) throw VALUE;
    this -> writeData(0,28,offset,8);
   }


   /*!
     @breif          BCLK N divider Value. Set to 0 to power the divider
     down.
     @param  value   The value of which to set to
     @return         Requested value. Do not set anything to read back 
     the value
   */
   //Power 0,30,7
   //0,30,6-0
   int bitClockNDivider(int value = 130){
    if(value == 0 && !this -> toggleable(0,30,7,true)) this -> toggleable(0,30,7);
    else if(value == 130) return this -> readData(0,30,7);
    else if(value != 0 && value != 130){
      if(this -> toggleable(0,30,7,true)) this -> toggleable(0,30,7);
      this -> writeData(0,30,value,8);
    }
   }



   ////************************** MULTIPLEXERS **************************\\\\
  
   /*!
     @breif                Determines where the CDIV Clock originates from
     @param  clockSource   The pin(or preexisting clock) to derive the CDIV Clock
     from, which is MCLK, BCLK, DIN, PLL, DAC_CLK, DAC_MOD_CLK, ADC_CLK, ADC_MOD_CLK
     @return               Set clockSource to READ to read back the current routing
   */
   //0,25,2-0
   int CDIVClock(KEYWORDS clockSource){
    if(clockSource == READ){
      int data = this -> readData(0,25,3,0);
      switch(data){
        case 0b000: return MCLK; case 0b001: return BCLK; case 0b010: return DIN;
        case 0b011: return PLL; case 0b100: return DAC_CLK; 
        case 0b101: return DAC_MOD_CLK; case 0b110: return ADC_CLK;
        case 0b111: return ADC_MOD_CLK;
      }
    }
    int data;
    switch(clockSource){
      case MCLK: data = 0b000; break; case BCLK: data = 0b001; break;
      case DIN: data= 0b010; break; case PLL: data = 0b011; break; 
      case DAC_CLK: data = 0b100; break; case DAC_MOD_CLK: data = 0b100; break; 
      case ADC_CLK: data = 0b110; break; case ADC_MOD_CLK: data = 0b111; break;
      default: throw VALUE;
    }
    this -> writeData(0,25,data,3,0);
   }


   /*!
     @breif                Determines where the BDIV Clock originates from
     @param  clockSource   The pin(or preexisting clock) to derive the BDIV Clock
     from, which is DAC, DAC_MOD, ADC, ADC_MOD
     @return               Set clockSource to READ to read back the current routing
   */
   //0,29,1-0
   00: BDIV_CLKIN = DAC_CLK
01: BDIV_CLKIN = DAC_MOD_CLK
10: BDIV_CLKIN = ADC_CLK
11: BDIV_CLKIN = ADC_MOD_CLK
   int BDIVClock(KEYWORDS clockSource){
    if(clockSource == READ){
      switch(clockSource){
        case 0b00: return DAC_CLK; case 0b01: return DAC_MOD_CLK; 
        case 0b10: return ADC_CLK; case 0b11: return ADC_MOD_CLK;
      }
    }
    int data;
    switch(clockSource){
      case DAC_CLK: data = 0b00; break; case DAC_MOD_CLK: data = 0b01; break;
      case ADC_CLK: data = 0b10; break; case ADC_MOD_CLK: data = 0b11; break;
      default: throw VALUE;
    }
    this -> writeData(0,29,data,2,0);
   }


   /*!
     @breif        Controls the location of the Secondary BCLK on the TLV3204. The
     default is GPIO, but which one eludes me. Cannot be the same as the Secondary
     WCLK location or the ADC Word CLock location
     @param  pin   The pin of which to route the secondary BCLK to. GPIO, SCLK,
     MISO, or DOUT are the pins
     @return       The current pin of which is routed to. Set pin to READ to read
     back the set value.
   */
   //0,31,6-5
   int secondaryBitClock(KEYWORDS pin){
    if(pin == READ){
      switch(this -> readData(0,31,2,5)){
        case 0: return GPIO; 
        case 1: return SCLK; 
        case 2: return MISO;
        case 3: return DOUT;
      }
    }
    this -> writeData(0,32,pin,2,5);
   }


   /*!
     @breif        Controls the location of the Secondary WCLK on the TLV3204. The
     default is GPIO, but which one eludes me. Cannot be the same as the Secondary
     BCLK location, Secondary WCLK location, or the Secondary Data In location
     @param  pin   The pin of which to route the secondary WCLK to. GPIO, SCLK,
     MISO, or DOUT are the pins
     @return       The current pin of which is routed to. Set pin to READ to read
     back the set value
   */
   //0,31,4-3
   int secondaryWordClock(KEYWORDS pin){
    if(pin == READ){
      switch(this -> readData(0,31,2,3)){
        case 0: return GPIO; 
        case 1: return SCLK; 
        case 2: return MISO;
        case 3: return DOUT;
      }
    }
    this -> writeData(0,31,pin,2,3);
   }


   /*!
     @breif        Controls the location of the ADC Word Clock on the TLV3204. The
     default is GPIO, but which one eludes me. Cannot be the same as the Secondary
     BCLK location, Secondary WCLK location, or the Secondary Data In location
     @param  pin   The pin of which to route the ADC Word Clock to. GPIO, SCLK, or
     MISO are the pins
     @return       The current pin of which is routed to. Set pin to READ to read
     back the set value
   */
   //0,31,2-1
   int analogInWordClock(KEYWORDS pin){
    if(pin == READ){
      switch(this -> readData(0,31,2,1)){
        case 0: return GPIO; 
        case 1: return SCLK; 
        case 2: return MISO;
      }
    }
    this -> writeData(0,31,pin,2,1);
   }


   /*!
     @breif        Controls the location of the ADC Word Clock on the TLV3204. The
     default is GPIO. Cannot be the same as the Secondary
     BCLK location, Secondary WCLK location, or the ADC Word Clock
     @param  pin   The pin of which to route the Secondary Data In to. GPIO or SCLK
     are the pins
     @return       The current pin of which is routed to. Set to READ to read back
     the set value
   */
   //0,31,0
   int secondaryDataIn(KEYWORDS pin){
    if(pin == READ){
      switch(this -> readData(0,31,1)){
        case 0: return GPIO; 
        case 1: return SCLK; 
      }
    }
    this -> writeData(0,31,pin,1);
   }






   ////************************** AUDIO SETTINGS **************************\\\\
 
   /*!
     @breif          DAC OSR(Oversampling) Setting register.
     NOTE: value should be a multiple of 2 while using Filter Type A, multiple of 4
     with Filter Type B and 8 with Filter Type C
     @param  value   What to set the register to. 1024, 2-1022.
     @retrun         Value of DAC OSR Register. Do not set anything to read back the
     DOSR
   */
   //0,13(1-0)-14(7-0)
   int analogOutOversampling(int value = 0){
    if(value == 0) return ((this -> readData(0,{13,14},10,0)));
    //Limits of the value. 1023 is not allowed, and of course someone will do it
    if(value < 0 || value > 1024 || value == 1023) throw VALUE;
    if(value == 1024) this -> writeData(0,{13,14},0,10,0);
    this -> writeData(0,{13,14},value,10,0);
   }


   /*!
     @breif           ADC Oversample Register.
     @param  value   The Oversampling Value.
     NOTE: 32 is with PRB_R13 to PRB_R18, Filter Type C, 64 is PRB_R1 to PRB_R12,
     Filter Type A or B, and 128 is PRB_R1 to PRB_R6, Filter Type A. 256 is the
     last value.
     @return         Value of the Oversample Value. Do not set anything to read
     back the set value.
   */
   //0,20,7-0
   int analogInOversampling(int value = 0){
    if(value == 0){
      value = this -> readData(0,20,8,0);
      if(value == 0b00000000) return 256;
      else return value;
    }
    if(log(value / 32) / log(2) < 0 || log(value / 32) / log(2) > 3) throw VALUE;
    if(value == 256) value = 0b00000000;
    this -> writeData(0,20,value,8,0);
   }


   /*!
     @breif              Determines the audio interface settings 
     @param  protocol    Interface for audio values. I2S, DSP, RJF, LJF. 
     @param  wordLength  The length of a word in bits. 16, 20, 24, and 32 bits
   */
   //Interface 0,27,7-6
   //Word Length 0,27,5-4
   void audioInterface(KEYWORDS protocal, int wordLength){
    int data;
    switch(protocal){
      case I2S: data = 0b00; break; case DSP: data = 0b01; break;
      case RJF: data = 0b10; break; case LJF: data = 0b11; break;
      default: throw VALUE;
    }
    if(wordLength % 4 != 0 || wordLength < 16 || wordLength > 32) throw VALUE;
    this -> writeData(0,27,(data << 2) + (wordLength - 16) / 2,4,4);
   }


   /*!
     @breif          Selects the Processing Block to use on the DAC.
     @param  block   The Signal Processing BLock to use: PRB_R1 to PRB_R25. Set
     block to be 1 to 25
     @return         The Block of which is currently being used. Do not set
     anything to read back the current Block
   */
   //0,60,4-0
   int analogOutSignalProcessingBlock(int block = 0){
    if(block == 0) return this -> readData(0,60,5,0);
    if(block > 25) throw VALUE;
    this -> writeData(0,60,block,5,0);
   }
   /*!
     @breif          Selects the Processing Block to use on the ADC.
     @param  block   The Signal Processing BLock to use: PRB_R1 to PRB_R18. Set
     block to be 1 to 18
     @return         The Block of which is currently being used. Do not set 
     anything to read back the current Block
   */
   //0,61,4-0
   int analogInSignalProcessingBlock(int block = 0){
    if(block == 0) return this -> readData(0,61,5,0);
    if(block > 18) throw VALUE;
    this -> writeData(0,61,block,5,0);
   }


////**************** MULTIFUNCTION PIN CONFIGURATION *****************\\\\


   /*!
     @breif                Controls the GPIO Pin on the TLV3204. This is pin 32,
     and can have the following states: Disabled, Secondary Audio Interface or
     Digital Microphone input or clock input, Input, Output, CLKOUT, INT1, INT2
     ADC_WCLK, Secondary BCLK, Secondary WCLK, Clock for Digital Microphone
     @param  function      What to set the GPIO function as.
     @return               Set function to READ to read back the set function of 
     the GPIO pin.
   */
   //0,52,5-0
   int generalInputOutputMFP5(KEYWORDS function){
    if(function == READ){
      switch(this -> readData(0,52,4,2)){
        case 0: return DISABLE; case 1: return MISC_APPLICATION;
        case 2: return INPUT_; case 3: return OUTPUT_;
        case 4: return CLKOUT; case 5: return INT1;
        case 6: return INT2; case 7: return ADC_WCLK_OUT;
        case 8: return SECOND_BCLK; case 9: return SECOND_WCLK;
        case 10: return DIGITAL_MIC_CLK;
      }
    }
    int data;
    switch(function){
      case DISABLE: data = 0; break; case MISC_APPLICATION: data = 1; break;
      case INPUT_: data = 2; break; case OUTPUT_: data = 3; break;
      case CLKOUT: data = 4; break; case INT1: data = 5; break;
      case INT2: data = 6; break; case ADC_WCLK_OUT: data = 7; break;
      case SECOND_BCLK: data = 8; break; case SECOND_WCLK: data = 9; break;
      case DIGITAL_MIC_CLK: data = 10; default: throw VALUE;
    }
    this -> writeData(0,52,data,4,2);
   }
   /*!
     @breif   The state of the GPIO Pin when used as a GPI. 
     @return  State of the GPI. true is a 1, false is 0
   */
   bool stateGPIO(){
    return this -> toggleable(0,52,1,true);
   }
   /*!
     @breif         What to set the GPIO Pin to when used as a GPO
     @param  state  The output state to set the GPIO pin as. true is 1, false
     is 0.
   */
   void outputGPIO(bool state){
    bool currentState = this -> toggleable(0,52,0,true);
    if(currentState == state) return;// Exit out of a void method
    this -> toggleable(0,52,0);// Runs only if the previous statement failed, so
    //the only reasonable thing to do is invert. 
   }
   /*!
     @breif                Controls the DOUT Pin on the TLV3204. This is pin 5, and
     can have the following states: Disabled, Primary DOUT for Audio Interface,
     GPO, Clock Out, INT1, INT2, Secondary BCLK, Secondary WCLK.
     @param  function      What to set the DOUT function as
     @return               The function of the DOUT pin. Set function to READ to 
     read back this value.
   */
   //0,53,4-0
   int dataOutMuxControl(KEYWORDS function){
    if(function == READ){
      switch(this -> readData(0,53,3,1)){
        case 0: return DISABLE; case 1: return PRIME_DOUT;
        case 2: return OUTPUT_; case 3: return CLKOUT;
        case 4: return INT1;    case 5: return INT2;
        case 6: return SECOND_BCLK; case 7: return SECOND_WCLK;
      }
    }
    int data;
    switch(function){
      case DISABLE: data = 0; break; case PRIME_DOUT: data = 1; break;
      case OUTPUT_: data = 2; break; case CLKOUT: data = 3; break;
      case INT1: data = 4; break; case INT2: data = 5; break;
      case SECOND_BCLK: data = 6; break; case SECOND_WCLK: data = 7; break;
      default: throw VALUE;
    }
    this -> writeData(0,53,data,3,1);
   }
   /*!
     @breif         What to set the DOUT Pin to when used as a GPO
     @param  state  The output state to set the DOUT pin as. true is 1, false
     is 0.
   */
   void outputDOUT(bool state){
    bool currentState = this -> toggleable(0,53,0,true);
    if(currentState == state) return;// Exit out of a void method
    this -> toggleable(0,53,0);// Runs only if the previous statement failed, so
    //the only reasonable thing to do is invert. 
   }
   /*!
     @breif                Controls the DIN Pin on the TLV3204. This is pin 4, and
     can have the following states: Disabled, Primary DIN or Digital Microphone
     input or Clock Input, or GPI. This function can only be used if Audio data
     is not being used.
     @param    function    What to set the DIN function as
     @return               Set function to READ to read back the current function
     of pin DIN
   */
   //0,54,2-0
   int dataInAudioControl(KEYWORDS function){
    if(function == READ){
      switch(this -> readData(0,54,2,1)){
        case 0: return DISABLE; case 1: return MISC_APPLICATION;
        case 2: return INPUT_;
      }
    }
    int data;
    switch(function){
      case DISABLE: data = 0; break; case MISC_APPLICATION: data = 1; break;
      case INPUT_: data = 2; break; default: throw VALUE; 
    }
    this -> writeData(0,54,data,2,1);
   }
   /*!
     @breif   The state of the DIN/MFP1 Pin when used as a GPI. 
     @return  State of the GPI
   */
   bool stateDIN(){
    return this -> toggleable(0,54,0,true);
   }
   /*!
     @breif                Controls the MISO Pin on the TLV3204. This is pin 11, and
     can have the following states: Disabled, Primary SPI Data Out, GPO, Clock Out,
     INT1, INT2, ADC WCLK Out, Digital Microphone Clock Output, Secondary DOUT,
     Secondary BCLK, Secondary WCLK. This function can only be used if SPI is not
     used.
     @param  function      What to set the MISO function as.
     @return               Set function to READ to read back the set function of the 
     MISO pin.
   */
   //0,55,4-0
   int dataInSPIControl(KEYWORDS function){
    if(function == READ){
      switch(this -> readData(0,55,4,1)){
        case 0: return DISABLE; case 1: return SPI_MODE; case 2: return OUTPUT_;
        case 3: return CLKOUT; case 4: return INT1; case 5: return INT2;
        case 6: return ADC_WCLK_OUT; case 7: return DIGITAL_MIC_CLK;
        case 8: return SECOND_DOUT; case 9: return SECOND_BCLK; 
        case 10: return SECOND_WCLK;
      }
    }
    int data;
    switch(function){
      case DISABLE: data = 0; break; case SPI_MODE: data = 1; break;
      case OUTPUT_: data = 2; break; case CLKOUT: data = 3; break;
      case INT1: data = 4; break; case INT2: data = 5; break;
      case ADC_WCLK_OUT: data = 6; break; case DIGITAL_MIC_CLK: data = 7; break;
      case SECOND_DOUT: data = 8; break; case SECOND_BCLK: data = 9; break;
      case SECOND_WCLK: data = 10; break; default: throw VALUE;
    }
    this -> writeData(0,55,data,4,1);
   }
   /*!
     @breif         What to set the DIN Pin to when used as a GPO
     @param  state  The output state to set the DIN pin as. true is 1, false
     is 0.
   */
   void outputDIN(bool state){
    bool currentState = this -> toggleable(0,55,0,true);
    if(currentState == state) return;// Exit out of a void method
    this -> toggleable(0,55,0);// Runs only if the previous statement failed, so
    //the only reasonable thing to do is invert. 
   }
   /*!
     @breif                Controls the SCLK Pin on the TLV3204. This is pin 8, and
     can have the following states: Disabled, SPI Clock in SPI or Secondary Data
     Input in I2C or Secondary Bit Clock or Secondary Word Clock or Secondary ADC
     Word Clock or Digital Microphone Input, or GPI. This function can only be used
     if SPI is not utilized.
     @param  function      What to set the SCLK function as
     @return               Set function to READ to read back the set function of the
     SCLK pin.
   */
   //0,56,2-0
   int clockSPIControl(KEYWORDS function){
    if(function == READ){
      switch(this -> readData(0,56,2,0)){
        case 0: return DISABLE; case 1: return MISC_APPLICATION;
        case 2: return INPUT_;
      }
    }
    int data;
    switch(function){
      case DISABLE: data = 0; break; case MISC_APPLICATION: data = 1; break;
      case INPUT_: data = 2; break; default: throw VALUE;
    }
    this -> writeData(0,56,data,2,0);
   }
   /*!
     @breif   The state of the SCLK/MFP3 Pin when used as a GPI. 
     @return  State of the GPI
   */
   bool stateSCLK(){
    return this -> toggleable(0,56,0,true);
   }




////************************** DAC SETUP/CONTROL **************************\\\\
   /*!
     @breif            Left/Right DAC Channel Path and Power Control.
     @param  channel   Which channel to select, true is Left, false is Right
     @param  path      Where the DAC Data is routed. 0 to disable, 1 for selected
     channel for Audio Interface Data, 2 is for the opposing Channel Audio
     Interface Data, and a 3 is a Mono Mix of both channel Audio Data.
     @return           The selected path. Do not set path to anything as the path 
     to read back the selected path.
   */
   //0,63,5-4,3-2
   int channelDACSetup(bool channel, int path = 4){
    if(path == 4) return this -> readData(0,63,2,(channel : 4 ? 2));
    if(path > 3) throw VALUE;
    this -> writeData(0,63,path,2,(channel : 4 ? 2));
   }
   /*!
     @breif            Controls the DAC Channel Volume Soft-Step. Default is 0,
     where Soft-Stepping is 1 step per 1 DAC WCLK, 1 has Soft-Stepping at 1 step per
     2 DAC WCLK, 2 is to disable Soft-Stepping.
     @param  setting   What to set the Soft-Stepping to
     @return           Soft-Stepping Setting. Do not set anything to read back the 
     setting.
   */
   //0,63,1-0
   int softStepDAC(int setting = 3){
    if(setting == 0) return this -> readData(0,63,2,0);
    if(setting > 2) throw VALUE;
    this -> writeData(0,63,setting,2,0);
   }
   /*!
     @breif                Controls when the DAC, on both channels, should mute if
     the incoming data is constant for a given amount of inputs
     @param  consecInput   How many consecutive inputs of audio data are linear(DC)
     and to mute after them. Allowed values are: 100, 200, 400, 800, 1600, 3200,
     and 6400. Set to 0 to mute.
     @return               Number of Consecutive Inputs required for auto mute. Do 
     not set anything to red back the set auto mute.
   */
   //0,64,6-4
   int autoMuteDAC(int consecInput = -1){
    if(consecInput == -1) return (100 * (2**(this -> readData(0,64,3,4) - 1)));
    if(consecInput < 100 || consecInput > 6400 
    //Cheaky maths to exclude any unallowed values.
    || log(1 + (consecInput % 100))/log(2) != 0) throw VALUE;
    this -> writeData(0,64,(log(consecInput / 100)/log(2)),3,4);
   }
   /*!
     @breif            Controls how the Master Volume is set on each of the channels.
     Default is 0, with each channel being independent from one another, 1 has Right
     control Left, 2 has Left control Right.
     @param  setting   What to set the Master Volume Control to
     @return           Master Volume Setting. Do not set anything to read back the 
     setting.
   */
   //0,64,1-0
   int masterVolumeDAC(int setting = 3){
    if(setting == 3) return this -> readData(0,64,2,0);
    if(setting > 2) throw VALUE;
    this -> writeData(0,64,setting,2,0);
   }
   /*!
     @breif          Controls the Digital Volume of the Left DAC. Depends on the
     Master Volume Control of the DAC.
     @param  volume  Digital Volume. Starts at +24dB, decreases at 0.5dB, and ends
     at -63.5dB. Set volume to be 10 times larger than the desired value. For instance,
     to set to 19.5, set volume to 195.
     @return         The Digital Volume setting. Do not set anything to read back the
     set value.
   */
   //0,65
   int leftChannelVolume(int volume = -640){
    if(volume == -640) return 5 * this -> readData(0,65,8);
    if(volume % 5 != 0 || volume < -635 || volume > 240) throw VALUE;
    this -> writeData(0,65,volume / 5,8,0);
   }
   /*!
     @breif          Controls the Digital Volume of the Right DAC. Depends on the
     Master Volume Control of the DAC.
     @param  volume  Digital Volume. Starts at +24dB, decreases at 0.5dB, and ends
     at -63.5dB. Set volume to be 10 times larger than the desired value. For instance,
     to set to 19.5, set volume to 195.
     @return         The Digital Volume setting. Do not set anything to read back 
     the set value.   
   */
   //0,66
   int rightChannelVolume(int volume = -640){
    if(volume == -640) return 5 * this -> readData(0,66,8);
    if(volume % 5 != 0 || volume < -635 || volume > 240) throw VALUE;
    this -> writeData(0,66,volume / 5,8,0);
   }




////************************** HEADSET **************************\\\\
   /*!
     @breif        Controls the time for a Headset Detection Debounce. On default,
     Headset detection is not enabled, but upon setting time to anything other than
     0, Headset Detection will be enabled. This feature is only available for I2C
     Communication.
     @param  time  Headset Debounce Time. 16ms, 32ms, 64ms, 128ms, 256ms, and 512ms
     @return       The set Detection Debounce. Do not set anything to read back.
   */
   //0,67,4-2
   int headsetDetectDebounce(int time = 0){
    if(time == 0) return (16 * (2 ** this -> readData(0,67,3,2)));
    if((log(time)/log(2)) % 16 != 0 || time < 0 || time > 512) throw VALUE;
    this -> writeData(0,67,((log(time) / log(2)) / 16),3,2);
   }
   /*!
     @breif        Controls the time for a Button Press Debounce. On default,
     Headset Debounce is disabled, but upon setting time to anything other than 0,
     Headset Button Debounce will be enabled.
     @param  time  Button Press Debounce Time. 0(disable), 8ms, 16ms, and 32ms
     @return       The set Button Debounce. Do not set anything to read back.
   */
   //0,67,1-0
   int headsetButtonDebounce(int time = 255){
    if(time == 255){
      time = this -> readData(0,67,2,0);
      if(time == 0) return 0;
    }
    if(time % 8 != 0 || time > 32){
      switch(time){
        case 0: time = 0; break; // Works for Read and Write
        case 8:  time = 1; break;
        case 1:  return 8;
        case 16: time = 2; break;
        case 2:  return 16;
        case 32: time = 3; break;
        case 3:  return 32; 
        default: throw VALUE;
      }
    }
    this -> writeData(0,67,time,2,0);
   }
   /*!
     @breif    Read only register of which tells what type of Headset has been
     detected. 
     @return   What Headset is currently detected. Given by the enum HEADSET_TYPE
   */
   //0,67,6-5
   int headsetType(){
    switch(this -> readData(0,67,2,5)){
      case 0: return NO_HEADSET;
      case 1: return STEREO_HEADSET;
      case 4: return STEREO_PLUS_CELLULAR_HEADSET;
    }
   }
   /*!
     @breif        Controls the Headphone Soft Routing Step Time. 0ms, 50ms, 100ms,
     and 200ms.
     @param  time  The Soft Routing Step Time
     @return       Soft Routing Step Time. Do not input anything to read back the 
     set value.
   */
   //1,20,7-6
   int softRoutingStepTime(int time = 255){
    if(time == 255){
      switch(this -> readData(1,20,2,6)){
        case 0b00: return 0; case 0b01: return 50; 
        case 0b10: return 100; case 0b11: return 200;
      }
    }
    switch(time){
      case 0: time = 0; break;
      case 50: time = 1; break;
      case 100: time = 2; break;
      case 200: time = 3; break;
      default: throw VALUE; break;
    }
    this -> writeData(1,20,time,2,6);
   }
   /*!
     @breif              Controls the Headphone Ramp Up Power with time constraints.
     The Time Contraints for the Ramp Up Power assume a 47uF Decoupling Capacitor
     @param  rampPower   Ramp up Power. 0 to disable, 0.5(50), 0.625(625),
     0.725(725), 0.875(875), 1, 2, 4, 5, 6, 7, 8, 16, 24, and 32. 
     16, 24, and 32 are to not be used with a Rchg of 25k. For the first four 
     values, set rampPower to the values in parenthesis to set the rampPower
     to that desired value.
     @param  resistance  The resistance that determines the Headphone Ramp Power time.
     2k, 6k, or 25k ohms of resistance. Set as 2, 6, and 25.
     @return             Ramp Up Power and Resistance. Do not set anything to read 
     back the values.
   */
   //1,20,5-2,1-0
   int headphoneRampPower(int rampPower = 0, int resistance = 0){
    bool read_ = false;
    if(rampPower == 0 && resistance == 0){
      rampPower = this -> readData(1,20,4,2);
      resistance = this -> readData(1,20,2,0);
      !read_;
    }
    switch(rampPower){
      case 0:   rampPower = 0;   break; // Works for both a read and write
      //For these, have some special cases since 8 is the same as 0b0100, ect.
      case 50:  rampPower = 0b0001;   break;  case 625: rampPower = 0b0010;   break;
      //Read
      case 0b0001:   rampPower = 50;  break;  case 0b0010:   rampPower = 625; break;
      case 725: rampPower = 0b0011;   break;  case 875: rampPower = 0b0100;   break;
      //Read
      case 0b0011:   rampPower = 725; break;  case 0b0100:   rampPower = 875; break;
      case 1:   rampPower = 0b0101;   break;  case 2:   rampPower = 0b0110;   break;
      //Read
      case 0b0101:   rampPower = 1;   break;  case 0b0110:   rampPower = 2;   break;
      case 3:   rampPower = 0b0111;   break;  case 4:   rampPower = 0b1000;   break;
      //Read
      case 0b0111:   rampPower = 3;   break;  case 0b1000:   rampPower = 4;   break;
      case 5:   rampPower = 0b1001;   break;  case 6:   rampPower = 0b1010;   break;
      //Read
      case 0b1001:   rampPower = 5;   break;  case 0b1010:  rampPower = 6;    break;
      case 7:   rampPower = 0b1011;   break;  case 8:   rampPower = 0b1100;   break;
      //Read
      case 0b1011:   rampPower = 7;   break;  case 0b1100:   rampPower = 8;   break;
      case 16:  rampPower = 0b1101;   break;  case 24:  rampPower = 0b1110;   break;
      //Read
      case 0b1101:   rampPower = 16;  break;  case 0b1110:   rampPower = 24;  break;
      case 32:  rampPower = 0b1111;   break; 
      //Read
      case 0b1111:   rampPower = 32;  break; 
      default: throw VALUE;
    }
    switch(resistance){
      case 2: resistance = 2; break;   case 0b00: resistance = 25; break;
      case 6: resistance = 1; break;   case 0b01: resistance = 6;  break;
      case 25: resistance = 0; break;
      default: throw VALUE; break;
    }
    if(read_) return rampPower, resistance;
    this -> writeData(1,20,rampPower,4,2);
    this -> writeData(1,20,resistance,2);
   }


////************************ VOLUME CONTROL ***********************\\\\
   /*!
     @breif          Controls the volume of different sections
     @param  route   The different system to change the volume of. IN1L to HPL,
     IN1R to HPR, MAL and MAR
     @param  volume  The volume of that section. Look at the datasheet provided,
     which is the first link, and go to pages 129 to 134 to find the volume. 
     @param  mute    Mute the selected system
   */
   void volumeControl(VOLUME_CONTROL_SELECTOR route, int volume, bool mute = false){}
   /*
    MAR: 1,25,5-0
    MAL: 1,24,5-0
    IN1R to HPR: 1,23,6-0
    IN1L to HPL: 1,22,6-0
   */




////********************** MICROPHONE CONTROL *********************\\\\
   //TODO: Cry, then implement the Microphone control


////****************** DYNAMIC RANGE CONTROL(DRC) ******************\\\\
   /*!
     @breif              The DRC(Dynamic Range Control) Threshold. Represents the 
     level of the DAC playback signal at whihc the gain compression becomes active. 
     Keeping too high may not leave enough time for DRC to detect peaking signals, 
     casuing excessive distrotion. Too low and it can limit the percieved loudness.
     @param  threshold   Value to set the DRC Threshold to. Starts at -3dBFS,
     increases by -3dBFS, and ends at -24dBFS. 
     @return             The set DRC Threshold. Do not set anything to read back
     the value.
   */
   //0,68,4-2
   int thresholdDRC(int threshold = 0){
    if(threshold % 3 != 0 || threshold < -24 || threshold > 0) throw VALUE;
    else if(threshold == 0) return this -> readData(0,68,3,2);
    else this -> writeData(0,68,~(threshold/3),3,2);
   }
   /*!
     @breif          DRC Hysteresis Value. The Hysteresis is a value that is around 
     the programmed DRC Theshold that must be exceeded for the DRC to change states.
     @param  value   What to set the DRC Hysteresis to. Starts at 0dB, increases by
     1dB, and ends at 3dB.
     @return         Value of this register. Do not set anything to read back the 
     value.
   */
   //0,68,1-0
   int hysteresisDRC(int value = 4){
    if(value > 4) throw VALUE;
    else if(value == 4) return this -> readData(0,68,2,0);
    else this -> writeData(0,68,value,2,0);
   }
   /*!
     @breif              Controls the DRC Hold Time based on how many DAC WCLKS pass.
     Slows the start of decay for a specified period of time in response to a decrease 
     in energy level.
     @param  wordClocks  How many WCLKS of the DAC to wait for. Starts at 32 WCLKS.
     Use the equation 2^(5+x), where 'x' ranges from 0 to 15. This determines how
     many WCLKS to hold at.
     @return             Total number of WCLKs, in the same manner as set(0-15). Do 
     not set anything to read back the value.
   */
   //0,69,4-3
   int holdTimeDRC(int wordClocks = 16){
    if(wordClocks > 16) throw VALUE;
    else if(wordClocks == 16) return this -> readData(0,69,4,3);
    else this -> writeData(0,69,wordClocks,4,3);
   }
   /*!
     @breif              Controls the DRC Attack Rate. The Attack Rate comes into 
     effect when the output of the DAC Digital Volume exceeds DRC Threshold, the 
     gain that is applied in DAC Digial Volume is progressivly reduces to avoid
     channel saturation. High rates cause audible artifacts, low rates may not 
     prevent signal clipping.
     @param  attackRate  The DRC Attack Rate. Starts at 4.0dB per DAC WCLK. Use
     the equation 2^-(2+x), where 'x' ranges from 0 to 15. This determines how many
     dB per DAC WCLK. Ends at 1.2207e-4dB
     @return             Rate per WCLK, in the same number as set(0-15). Do not 
     set anything to read back the value.
   */
   //0,70,7-4
   int attackRateDRC(int attackRate = 16){
    if(attackRate > 16) throw VALUE;
    else if(attackRate == 16) return this -> readData(0,70,4,4);
    else this -> writeData(0,70,attackRate,4,4,);
   }
   /*!
     @breif              Controls the DRC Decay Rate. Decay Rate is used when a 
     reduction in output signal swing beyond DRC Threshold is detected by the DRC, 
     so the DRC enters a Decay State, where the gain applied in Digital Volume Control
     is gradually increased. To high, and sudden gain changes caus audible artifacts. 
     Too low, and the ouput may be percived as too low for a long time after peak 
     signal.
     @param  decayRate   The DRC Decay Rate. Starts at 1.5625e-2dB. Use the equation
     1.5625e-2 * 2^-(x), where 'x' ranges from 0 to 15. This determines how many dB
     to Decay at per DAC WCLK. Ends at 7.7683e-7dB
     @return             Rate per WCLK, in the same number as set(0-15). Do not set 
     anything to read back the value.
   */
   //0,70,3-0
   int decayRateDRC(int decayRate = 16){
    if(decayRate > 16) throw VALUE;
    else if(decayRate == 16) return this -> readData(0,70,4,0);
    else this -> writeData(0,70,decayRate,4,0);
   }




////********* ANALOG TO DIGITAL CONVERTER SETTINGS(ADC) ************\\\\
   /*!
     @breif          Digital Microphone signal routing. Default is 0, where GPIO
     serves as the Digital Microphone Input, 1 SCLK, 2 DIN.
     @param  input   Where the Digital Microphone Input on the TLV3204 is to be routed
     @return         Current signal routing. Do not set anything to read back the value.
   */
   //0,81,5-4
   int digitalMicrophoneInputConfig(int input = 3){
    if(input > 3) throw VALUE;
    else if(input == 3) return this -> readData(0,81,2,4);
    else this -> writeData(0,81,input,2,4);
   }
   /*!
     @breif            ADC Volume Soft-Stepping Control. Default is 0, where ADC
     Volume Control changes by 1 gain step per ADC WCLK, 1 changes by 1 gain step
     per two ADC WCLK, 2 to disable.
     @param  setting   What to set the Soft-Stepping to
     @return           Soft-Stepping setting. Do not set anything to read back the value.
   */
   //0,81,1-0
   int softStepADC(int setting = 3){
    if(setting > 3) throw VALUE;
    else if(setting == 3) return this -> readData(0,81,2,0);
    else this -> writeData(0,81,setting,2,0);
   }
   /*!
     @breif        Controls the ADC Left Channel Fine Gain. Starts at 0dB, increases
     by -0.1dB, ends at -0.4dB. Put gain as a whole number of what to set it to, like 
     -3 as -0.3dB.
     @param  gain  The Fine Gain to set to
     @return       Fine Gain for Left ADC. Do not set anything to read back the 
     set gain.
   */
   //0,82,6-4
   int leftFineGain(int gain = 1){
    if(gain == 1){
      gain = this -> readData(0,82,3,4);
      if(gain == 0) return 0;// Special case
      gain = ~gain;// Inverts the number to positive
      return -(gain + 1);
    }
    if(gain < -4 || gain > 0) throw VALUE;
    this -> writeData(0,82,gain,4);
   }
   /*!
     @breif        Controls the ADC Right Channel Fine Gain. Starts at 0dB, increases
     by -0.1dB, ends at -0.4dB. Put gain as a whole number of what to set it to, like 
     -3 as -0.3dB.
     @param  gain  The Fine Gain to set to
     @return       Fine Gain for Right ADC. Do not set anything to read back the set 
     gain
   */
   //0,82,2-0
   int rightFineGain(int gain = 1){
    if(gain == 1){
      gain = this -> readData(0,82,3,0);
      if(gain == 0) return 0;// Special case
      gain = ~gain;// Inverts the number to positive
      return -(gain + 1);
    }
    if(gain < -4 || gain > 0) throw VALUE;
    this -> writeData(0,82,gain,3,0);
   }
   /*!
     @breif          Controls the Left ADC Volume. Ranges from -12dB, increases by
     0.5dB and ends at 20.0dB. Input as a whole number, such as for -5.5dB, set at
     -55.
     @param  volume  The volume of the Left ADC Channel
     @return         Volume of the Left ADC. Returned in the same format as updated.
     Do not set anything to read back the value.
   */
   //0,83,6-0
   int leftADCVolume(int volume = 255){
    if(volume == 255) return (5 * this -> readData(0,83,7,0));
    if(volume % 5 != 0 || volume < -120 || volume > 200) throw VALUE;
    else this -> writeData(0,84,volume,7,0);
   }
   /*!
     @breif          Controls the Right ADC Volume. Ranges from -12dB, increases by
     0.5dB and ends at 20.0dB. Input as a whole number, such as for -5.5dB, set at
     -55 or 19.5dB as 195.
     @param  volume  The volume of the Right ADC Channel
     @return         Volume of the Right ADC. Returned in the same format as updated.
     Do not set anything to read back the value.
   */
   //0,84,6-0
   int rightADCVolume(int volume = 255){
    if(volume == 255) return (5 * this -> readData(0,84,7,0));
    if(volume % 5 != 0 || volume < -120 || volume > 200) throw VALUE;
    else this -> writeData(0,84,volume,7,0);
   }
   /*!
     @breif            ADC Phase Compensation Control. Only one Channel can be
     put out of phase. 
     @param   samples  How many samples to dealy the phase by. Negative to delay
     the Left Channel, positive for the right.
     @return           Phase Compensation currently set.
   */
   int phaseCompensationADC(int samples){
    this -> writeData(0,85,samples,8,0);
   }


////***************** AUTOMATIC GAIN CONTROL(AGC) ********************\\\\
   /*!
     @breif    Determines which channel, Right or Left, of the AGC to be changing.
     This applies to targetLevelAGC, hysteresisAGC, noiseSettingAGC, attackAGC, and
     decayAGC. Before calling, the selected channel is Left(true). Right
     channel is false.
   */
   bool channelSelectorAGC(){ selectedChannelAGC = false; }
   /*!
     @breif    Determines if a read operation should occur. After each read, it is 
     required to call this again. It applies to targetLevelAGC, hysteresisAGC, 
     noiseSettingAGC, attackAGC, and decayAGC.
   */
   bool readAGC(){ read_ = true; }
   /*!
     @breif          AGC Target Level Setting. -5.5dBFS to -24.0dBFS. Possible numbers
     are 55(-5.5dBFS), 8, 10, 12, 14, 17, 20, 24
     @param  level   Target Level Setting
     @return         The Target Level Setting.
   */
   //0,94,6-4
   //0,86,6-4
   int targetLevelAGC(int level = 0){
    bool pass = false;
    if(read_ && level == 0){
      level = this -> readData(0,(!selectedChannelAGC ? 94 : 86),3,4);
      selectedChannelAGC = true;
      read_ = false;
      switch(level){
        case 0b001: return 8;
        case 0b010: return 10;
        case 0b011: return 12;
        case 0b100: return 14;
        case 0b101: return 17;
        case 0b110: return 20; 
        case 0b111: return 24;
        case 0b000: return 55;
      }
    }
    if(level < 8 || (level < 55 && level > 24) || level > 55) throw VALUE;
    else{
      switch(level){
        case 8: level = 0b001; break;
        case 10: level = 0b010; break;
        case 12: level = 0b011; break;
        case 14: level = 0b100; break;
        case 17: level = 0b101; break;
        case 20: level = 0b110; break; 
        case 24: level = 0b111; break;
        case 55: level = 0b000; break;
        //Prevents an invalid value that made it through the first check from 
        //existing
        default: pass = true; break; 
      }
    }
    if(!selectedChannelAGC && !pass) this -> writeData(0,94,level,3,4); 
    else if(selectedChannelAGC && !pass) this -> writeData(0,86,level,3,4);
    // Reset Channel Selector
    selectedChannelAGC = true;
    // Send an error
    if(pass) throw VALUE;
   }
   /*!
     @breif            Hysteresis Setting. A setting around the Noise Threshold
     avoids fluctuations of ADC between target and no signal when the signal is around
     the noise threshold. Channel is determined by channelSelector
     @param  gain      AGC Hysteresis Gain. 0 to disable, 5(+-0.5dB), 10(+-1.0dB), and
     15(+-1.5dB)
     @param  setting   AGC Hysteresis Setting. 0 to disable, 1.0dB, 2.0dB, and 4.0dB
     @return           The Hysteresis Gain and Setting. Returned in an array in said 
     order.
   */
   //Gain 0,94,1-0
   //Setting 0,95,7-6
   //Gain 0,86,1-0
   //Setting 0,87,7-6
   int hysteresisAGC(int gain = 0, int setting = 0){
    bool pass = true;
    if(read_ && gain == setting == 0){
      setting = this -> readData(0,(!selectedChannelAGC ? 95 : 87),2,6);
      gain = this -> readData(0,(!selectedChannelAGC ? 94 : 86),2,0);
      switch(setting){
        case 0b11: setting = 0; break;
        case 0b00: setting = 1; break;
        case 0b01: setting = 2; break;
        case 0b10: setting = 4; break;
      }
      selectedChannelAGC = true;
      read_ = false;
      return gain*5,setting;
    }else
    if(gain % 5 != 0 && (gain <= 0 || gain >= 15)) throw VALUE;
    if(setting < 0 || setting > 4) throw VALUE;
    switch(setting){
      case 0: setting = 0b11; break;
      case 1: setting = 0b00; break;
      case 2: setting = 0b01; break;
      case 4: setting = 0b10; break;
      default: pass = false; break;
    }
    if(pass){
      this -> writeData(0,(!selectedChannelAGC ? 94 : 86),gain/5,2,0);
      this -> writeData(0,(!selectedChannelAGC ? 95 : 87),setting,2,6);
      selectedChannelAGC = true;
    }else throw VALUE;
   }
   /*!
     @breif                   Controls the Signal Debounce time, Noise Debounce time, 
     and Noise Threshold of an AGC Channel. If any value is invalid precedding others, 
     for instance, if the noiseDebounce is set improperly, the Signal Debounce will 
     still be updated.
     @param  signalDebounce   AGC Signal Debounce Time. The ADC WCLKs can be 
     determined with the following Piecewise Function:
     y = (2^x)(x<9) + (2^(x+1))(x>=9)
     where x determines what to set the Signal Debounce time multiple to, and y is
     the time in ADC WCLKs. The minimum is 0(0), and the maximum is 65536, or x = 15.
     To set the Debounce Time to 0, set signalDebounce to 0.
     @param  noiseThreshold   AGC Noise Threshold. Starts at -30dB and goes to -90dB.
     Increases by -2dB.
     @param  noiseDebounce    Noise Debounce Time. The ADC WCLK's can be determined 
     with the following Piecewise Function: 
     y = (2^x)(x<10) + 2^(x+1))(x>=10)
     where x determines what to set the Noise Debounce time multiple to, and y is 
     the time in ADC WCLKs. The minimum is 0(0), and the maximum is 85,899,345,920, or
     x = 31. To set the Debounce Time to 0, set noiseDebounce to 0.
     @return                  The Signal Debounce, Noise Threshold, and Noise Debounce,
     returned in an array in the respective order.
   */
   int noiseSettingAGC(int signalDebounce = 0, int noiseThreshold = 0, 
   int noiseDebounce = 0){
    bool pass = true;
    if(read_ && signalDebounce == noiseThreshold == noiseDebounce == 0){
      signalDebounce = this -> readData(0,(!selectedChannelAGC ? 100 : 92),4,0);
      noiseDebounce = this -> writeData(0,(!selectedChannelAGC ? 99 : 91),5,0);
      noiseThreshold = this -> writeData(0,(!selectedChannelAGC ? 95 : 87),5,1);
      selectedChannelAGC = true;
      read_ = false;
      return signalDebounce, noiseThreshold, noiseDebounce;
    }else pass = false;
    if(signalDebounce < 0 || signalDebounce > 15) pass = false;
    if((noiseThreshold % 2 != 0 || noiseThreshold < -90 || noiseThreshold > -30)
    && pass == true){
      pass = false;
    }else{
      //Makes it positive, I hope
      noiseThreshold -= 2 * noiseThreshold;
      //Offsets to 0 and divides by 2
      noiseThreshold = (noiseThreshold - 30) / 2;
    }
    if((noiseDebounce < 0 || noiseDebounce > 31) && pass == true) pass = false;
    if(pass){
      this -> writeData(0,(!selectedChannelAGC ? 100 : 92),signalDebounce,4,0);
      this -> writeData(0,(!selectedChannelAGC ? 99 : 91),noiseDebounce,5,0);
      this -> writeData(0,(!selectedChannelAGC ? 95 : 87),noiseThreshold,5,1);
      selectedChannelAGC = true;
    }else{
      selectedChannelAGC = true;
      read_ = false;
      throw VALUE;
    }
   }
   /*
    Right Gain(READ) 0,101
    Left Gain(READ) 0,93
    Right Signal Debounce 0,100,3-0
    Left Signal Debounce 0,92,3-0
    Right Noise Debounce 0,99,4-0
    Left Noise Debounce 0,91,4-0
    Right Noise Threshold, 0,95,5-1
    Left Noise Threshold 0,87,5-1
   */
   /*!
     @breif        Controls the AGC MAximum Gain. Values range from 0.0dB(0) to
     58.0dB(580) and increase by 0.5dB. To change the Maximum Gain, write the 
     value that is desired, multiplied by ten. For instance, to set the Maximum 
     Gain to 48.5dB, set gain to 485.
     @param  gain  The Maximum Gain to set the AGC to.
     @return       The Maximum Gain.
   */
   int maxGainAGC(int gain = 0){
    if(read_ && gain == 0){
      int data = this -> readData(0,(!selectedChannelAGC ? 96 : 88),7,0);
      selectedChannelAGC = true;
      read_ = false;
      return data * 5;
    }else if(read_ && gain != 0) throw VALUE;
    else if(gain % 5 != 0 || gain < 0 || gain > 580){
      read_ = false;
      selectedChannelAGC = true;
      throw VALUE;
    }else{
      if(!selectedChannelAGC) this -> writeData(0,96,gain/5,7,0);
      else this -> writeData(0,88,gain/5,7,0);
    }
   }
   /*
    Right Max Gain 0,96,6-0
    Left Max Gain 0,88,6-0
   */
   /*!
     @breif          AGC response time to an increase in the input amplitude.
     @param  time    AGC Attack Time in ADC WCLKs. Starts at 1*32, goes to 63*32.
     Select only the first number, for instance, setting 46*32, set time to 46
     @param  scale   Scaling factor for the Attack Time. Starts at 1, goes to 128.
     Increases by y=2^x, where x represents the scale factor, y is the value to set
     scale to.
     @return         The Attack Time and the Attack Scale, returned in an array and 
     as the same manner as set.
   */
   //0,97
   //0,89
   int attackAGC(int time = 0, int scale = 0){
    bool pass = true;
    if(read_ && time == scale == 0){
      time = this -> readData(0,(!selectedChannelAGC ? 97 : 89),5,3);
      scale = this -> readData(0,(!selectedChannelAGC ? 97 : 89),3,0);
      selectedChannelAGC = true; 
      read_ = false;
      return time + 1, 2 ** scale;
    }else pass = false;
    if((time - 1) % 2 != 0 || time > 1 || time < 63) pass = false;
    if(scale > 1 || scale < 128) pass = false;
    if(pass){
      this -> writeData(0,(!selectedChannelAGC ? 97 : 89),time - 1,5,3);
      this -> writeData(0,(!selectedChannelAGC ? 97 : 89),(log(scale)/log(2)-1),3,0);
      selectedChannelAGC = true;
    }else{
      read_ = false;
      selectedChannelAGC = true;
      throw VALUE;
    }
   }
   /*!
     @breif          AGC response time to a decrease in the input amplitude.
     @param  time    AGC Decay Time, in ADC WCLKs. Starts at 1*512, ends at
     63*512, and increases by 2*512. Input only the first number, for instance, 
     setting 25*512, set time to 24.
     @param  scale   Scaling factor for the Decay Time. Starts at 1, goes to 128.
     Use y=2^x, where x is the Factor, and y is the desired Scale Factor
     @return         The Decay Time and the Decay Scale, returne in an array and 
     as the same manner as set.
   */
   //0,98
   //0,90
   int decayAGC(int time = 0, int scale = 0){
    bool pass = true;
    if(read_ && time == scale == 0){
      time = this -> readData(0,(!selectedChannelAGC ? 98 : 90),5,3);
      scale = this -> readData(0,(!selectedChannelAGC ? 98 : 90),3,0);
      selectedChannelAGC = true;
      read_ = false;
    }else if(read_ && time != 0 || scale != 0) pass = false;
    if((time - 1) % 2 != 0 || time < 1 || time > 63) pass = false;
    if(scale < 1 || scale > 128) pass = false;
    if(pass){
      this -> writeData(0,(!selectedChannelAGC ? 98 : 90),5,3);
      this -> writeData(0,(!selectedChannelAGC ? 98 : 90),(log(scale)/log(2)),3,0);
      selectedChannelAGC = true;
    }else{
      selectedChannelAGC = true;
      read_ = false;
      throw VALUE;
    }
   }


////********************** ADC POWERTUNE *****************************\\\\
   /*!
     @breif        Analog Input(s) Power Up Time. 3.1, 6.4, and 1.6. Set 
     as 31, 64, and 16, respectively. The defaut value is, on startup, 
     0, and that is not a valid value. For reading back, set time equal 
     to 0.
     @param  time  The time to set to. 
     @return       The time. Returned in the same manner as set.
   */
   //1,71,5-0
   int analogInputPowerTime(int time){
    if(time == 0){
      time = this -> readData(1,71,6) & 0b000000;
      if(time == 0b00) return 16;// 1.6 ms
      else if(time = 0b01) return 64;// 6.4 ms
      else if(time = 0b10) return 36;// 3.6 ms
    }
    int value = 0b110000;
    if(time == 16) value += 1;
    else if(time == 31) value += 2;
    else if(time == 64) value += 4;
    else throw VALUE;// Someone was being funny and gave an invalid number
    this -> writeData(1,71,value,6);
   }
   /*!
    @breif        Controls the ADC PowerTune Configuration. Default is R4, 
    and the options are PTM_R1, PTM_R2, PTM_R3, and PTM_R4. Set to READ to 
    read back the value of this register
    @param  ptm   The PTM to set to. 
    @return       Value of the ADC PTM, when requested.
   */
   int analogInPowerTuneConfig(KEYWORDS ptm = READ){
    if(ptm == READ) return this -> readData(1,61,8);
    this -> writeData(1,61,ptm,8);
   }


////************************ BEEP GENERATOR ************************\\\\
   /*!
     @breif                  Controls the volume of the Beep Generator. Upon 
     calling this method, a beep will be generated with whatever parameters are
     either set as the default, or after setting the parameters using the 
     methods beepTime, 
     @param  left            Left Channel Beep Volume
     @param  right           Right Channel Beep Volume
     @param  masterSetting   Determines how the volume is to be controlled. 0 for
     independent volume control, 1 for Left to be equal to Right, 2 for Right to be
     equal to Left.
     @return                 true if the beep was set and succesfull. false if 
     something went wrong
   */
   //Right 0,72,5-0
   //Left 0,71,5-0
   bool beepVolumeControl(int left, int right, int masterSetting){
    if(left < -63 || left > 0 || right < -63 || right > 0 
    || masterSetting > 2) throw VALUE;
    // Updating the volume. Right then Left
    this -> writeData(0,72,~right,6,0); this -> writeData(0,71,~left,6,0);
    this -> writeData(0,72,masterSetting,2,6);// Master Volume Control
    //DAC_FS = CODEC_CLKIN / (NDAC x MDAC x DOSR)
    int codecFreq;// In MHz
    float dacFS;// In MHz
    int dosr = this -> readData(0,{13,14},10,0);
    int ndac = this -> readData(0,11,7,0);
    int mdac = this -> readData(0,12,7,0);
    int nadc = this -> readData(0,18,7,0);
    bool ndacState = (ndac % 2 == 0);
    bool nadcState = (nadc % 2 == 0);
    if(ndacState == nadcState == true) codecFreq = 137;
    else if(ndacState == !nadcState == true) codecFreq = 112;
    else codecFreq = 110;
    dacFS = (codecFreq * 1000000) / (ndac * mdac * dosr);
    float time = this -> beepTime() * dacFS ** -1;// Should be in seconds
    // Triggers the Beep
    this -> toggleable(0,71,7);// Since the beep clears this bit, only need to flip
    delay(time * 1000 + 1);// Waits for the beep to elapse, plus a little extra
    return this -> toggleable(0,71,7,true);// Since toggleable gives a bool, the 
    //state of the bit can be used as the status. The method does not know the 
    //status of the beep generator
   }
   /*!
     @breif        Controls the frequency of the Beep Generator. The maximum 
     frequency that can be done is up to DAC_FS / 2
     @param  freq  The frequency of the Two's-Complement Sine-Wave and 
     Cosine-Wave.
     @return       DAC_FS, when nothing is set.
   */
   //Sin: 76-77
   //Cos: 78-79
   float beepFrequency(float freq = 0){
    //Calculations to determine the DAC_FS
    int codecFreq;// In MHz
    float dacFS;// In MHz
    int dosr = this -> readData(0,{13,14},10,0);
    int ndac = this -> readData(0,11,7,0);
    int mdac = this -> readData(0,12,7,0);
    int nadc = this -> readData(0,18,7,0);
    bool ndacState = (ndac % 2 == 0);
    bool nadcState = (nadc % 2 == 0);
    if(ndacState == nadcState == true) codecFreq = 137;
    else if(ndacState == !nadcState == true) codecFreq = 112;
    else codecFreq = 110;
    dacFS = (codecFreq * 1000000) / (ndac * mdac * dosr);
    if(freq == 0) return dacFS;// Gives the DAC_FS when requested
    if(freq <= 0 || freq > dacFS / 2) throw VALUE;
    // The above statements break out of the method, so an if-else is not required
    float sin_ = sin(2 * PI * (freq / dacFS));
    float cos_ = cos(2 * PI * (freq / dacFS));
    //Special case where my home-brew method for writing an array will not work
    //Maybe the Wire.h will automatically issue another start command. Who knows.
    Wire.beginTransmission(DEVICE_ADDRESS);// Begin communication
    Wire.write(0);// Write condition
    Wire.write(76);// The Register of a Page to select
    Wire.write(sin_);// Writes the compiled data
    Wire.endTransmission();
    Wire.beginTransmission(DEVICE_ADDRESS);// Begin communication
    Wire.write(0);// Write condition
    Wire.write(78);// The Register of a Page to select
    Wire.write(cos_);// Writes the compiled data
    Wire.endTransmission();
   }
   /*!
     @breif        Controls the duration of the Beep Generator. The resoulution of
     the time is one sample time of the DAC, or DAC_FS. The default duration is 
     228(0b11101110) cycles.
     @param  time  The duration of the Beep Generator. A maximum of 16777215(2**24).
     Can be any value between 0 and the maximum.
     @return       Current duration. Do not set anything to read back the value.
   */
   //0,73-75
   int beepTime(int time = -1){
    if(time == -1) return this -> readData(0,{73,74,75},24,0);
    if(time < 0 || time > 2**24) throw VALUE;// Checking for values small or large
    // throw automatically breaks out of method, otherwise continue with write
    this -> writeData(0,{73,74,75},time,24,0);
   }
////************************ DC MEASUREMENT ************************\\\\
   //0,102,5
   bool powerMeasureFilter(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,102,5,true);
    }
    this -> toggleable(0,102,5);
   }
   /*!
     @breif    For IIR based DC Measurements, the measurement value is the
     instantaneous output of the IIR Filter(0), or the measurement value is
     updated before the periodic cleaning of the IIR Filter(1). Set by
     powerMeasureIIR function
     @return   State of this register
   */
   //0,103,5
   bool powerMeasureIIR(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,103,5,true);
    }
    this -> toggleable(0,103,5);
   }
   /*!
     @breif      DC Measurement D Setting. Starts at 1, ends at 20. 
     @param  D   Value of the DC Measurement D Parameter
     @return     The value of the DC Measurement D. Do not set anything to read back
     the current value.
   */
   //0,102,4-0
   int powerMeasureD(int D = 0){
    if(D == 0) return this -> readData(0,102,5,0);
    if(D > 20) throw VALUE;
    else this -> writeData(0,102,D,5,0);
   }
   /*!
     @breif        The average time setting for a IIR based DC Measurement. IIR means
     Infinite Impulse Response Filter, which is a recursive filter that has the output
     from the filter being computed by the current inputs, previous inputs, and the
     previous outputs. Setting it to 0 has it as an Infinite Average, 1 for 2E1, 
     2 for 2E2, ect. Goes up to 2E20. 
     @param  time  Averaging Time Setting for the IIR Filter. 
     @return       The value of the DC Measurement IIR Time setting. Do not set 
     anything to read back the current value
   */
   //0,103,4-0
   int powerMeasureIIR(int time = 25){
    if(time == 25) return this -> readData(0,103,5,0);
    if(time > 20) throw VALUE;
    else this -> writeData(0,103,time,5,0);
   }
   /*!
     @breif            Reads the DC Measurement data from a selected channel.
     @param  channel   The ADC Channel to read the DC from. false is Left, true is
     Right
     @return           The DC Measurement of a channel
   */
   //Left: 0, 104(23:16)-106(7:0)
   //Right: 0, 107(23:16)-109(7:0)
   float powerMeasurement(bool channel = false){
    //DC Measurments are latched into read registers
    if(!toggleable(0,103,6,true)) toggleable(0,103,6);
    int measure;
    if(channel){
      //Right Channel Read\\
      //Enable DC Measurement for Right Channel
      if(!toggleable(0,102,6,true)) toggleable(0,102,6);
      //Get the data in 24 bit format from the registers
      measure = readData(0,int{107,108,109},24,0);
    }else{
      //Left Channel Read\\
      //Enable DC Measurement for Left Channel
      if(!toggleable(0,102,7,true)) toggleable(0,102,7);
      //Get the data in 24 bit format from the registers
      measure = readData(0,{104,105,106},24,0);
    }
    bool sign = ((measure << 23) == 1);// Sign. 1 is true, 0 is false. 
    //Don't know what that entails
   }



//
   /*!
     @breif          Controls the voltage of the DVDD LDO(Low Drop-Out). The 
     values are 172(1.72V), 162(1.62V), and 177(1.77V). 
     @param  output  The voltage to set DVDD LDO. 
     @return         The voltage set. Do not set anything to read back the 
     DVDD LDO. Returned in the same manner as set
   */
   //1,2,7-6
   int digitalLDOControl(int output = 0){
    if(output == 0){
      output = this -> readData(1,2,2,6);
      switch(output){
        case 0: return 172;
        case 1: return 167;
        case 2: return 177;
      }
    }else{
      switch(output){
        case 172: this -> writeData(1,2,0b00,2,6); break;
        case 167: this -> writeData(1,2,0b01,2,6); break;
        case 177: this -> writeData(1,2,0b10,2,6); break;
        default: throw VALUE; 
      }
    }
   }
   /*!
     @breif          Controls the voltage of the AVDD LDO(Low Drop-Out). The 
     values are 172(1.72V), 162(1.62V), and 177(1.77V). 
     @param  output  The voltage to set AVDD LDO. 
     @return         The voltage set. Do not set anything to read back the AVDD
     LDO setting. Returned in the same manner as set
   */
   //1,2,5-4
   int analogLDOControl(int output = 0){
    if(output == 0){
      output = this -> readData(1,2,2,4);
      switch(output){
        case 0: return 172;
        case 1: return 167;
        case 2: return 177;
      }
    }else{
      switch(output){
        case 172: this -> writeData(1,2,0b00,2,4); break;
        case 167: this -> writeData(1,2,0b01,2,4); break;
        case 177: this -> writeData(1,2,0b10,2,4); break;
        default: throw VALUE; 
      }
    }
   }


   /*!
     @breif        Controls the Left DAC PTM Mode. PTM is Pulse-Time Modulation.
     @param  mode  The DAC PTM mode. 3 for PTM_P1, 2 for PTM_P2, 1 for PTM_P3
     and PTM_P4, for some reason. 
     @return       Selected Mode. Do not set anything to read back
   */
   //1,3,4-2
   int leftDACPTM(int mode = 0){
    if(mode == 0) return this -> readData(1,3,3,2);
    if(mode > 3) throw VALUE;
    else this -> writeData(1,3,mode,3,2);
   }
   /*!
     @breif        Controls the Right DAC PTM Mode. PTM is Pulse-Time Modulation.
     @param  mode  The DAC PTM mode. 3 for PTM_P1, 2 for PTM_P2, 1 for PTM_P3
     and PTM_P4, for some reason. 
     @return       Selected Mode. Do not set anything to read back
   */
   //1,4,4-2
   int rightDACPTM(int mode = 0){
    if(mode == 0) return this -> readData(1,4,3,2);
    if(mode > 3) throw VALUE;
    else this -> writeData(1,4,mode,3,2);
   }


   /*!
     @breif            Sets the Debounce Time for an Over Current Detection Event.
     Starts at 8ms, ends at 512ms. Doubles each time. 0 disables the debounce
     @param  debounce  The Debounce time for an Over Current Detection. 
     @return           The current Debounce Time. Do not set anything to read back.
   */
   //1,11,1-3
   int overCurrentDebounce(int debounce = -1){
    if(debounce == -1){
      debounce = this -> readData(1,11,3,1);
      if(debounce == 0) return 0;
      return 8 * 2**debounce;
    }
    if(debounce % 8 != 0 || debounce < 0 || debounce > 512) throw VALUE;
    if(debounce == 0) this -> writeData(1,11,0,3,1);// log will not get 0 here
    else this -> writeData(1,11,log(debounce / 8) / log(2),3,1);
   }


   /*!
     @breif          High Power Left and Right and Low Output Left and Right gain
     and mute control. Gain ranges from -6dB to 29dB. Increases by 1dB. For High
     Power Drivers, they cannot be muted when set to -6dB and are not valid when
     the diver is set in Class-D mode
     @param  driver  Which driver to use. 0 for HPL, 1 for HPR, 2 for LOL, 3 for
     LOR
     @param  mute    true to mute the driver, false to unmute. Takes priority over
     the set gain.
     @param  gain    The gain setting
   */
   void driverGainAndMute(int driver, bool mute, int gain){
    if(driver > 3) throw VALUE;
    if(gain < -6 || gain > 29) throw VALUE;
    int reg;
    switch(driver){
      case 0: reg = 16; break; case 1: reg = 17; break;
      case 2: reg = 18; break; case 3: reg = 19; break;
    }
    if(mute){
      this -> toggleable(1,reg,6);
      return;
    }
    this -> writeData(1,reg,gain,6,0);
   }
   /*
    Mute LOR: 1,19,6
    Mute LOL: 1,18,6
    Mute HPR: 1,17,6
    Mute HPL: 1,16,6
    LOR Driver Gain: 1,19,5-0
    LOL Driver Gain: 1,18,5-0
    HPR Driver Gain: 1,17,5-0
    HPL Driver Gain: 1,16,5-0
   */
   /*!
     @breif          Determines the routing of a Mixer Amplifier signal. MAR can 
     be to LOR, HPR, and HPL. MAL can be LOL and HPL. These registers act as 
     toggable ones. The default for all is that MAL/MAR is not routed to them
     @param route    The route of which to set a Mixer Amplifier to. 
     @param channel  The channel to set. false is the left channel, true is right
     @return         Setting the route to READ and the selected channel causes a 
     read. The MULTIPLE_SELECT Error can occur. The error only occurs on the next
     read after one is overset.
   */
   //1,12,1
   int mixerAmplifierRoute(KEYWORDS route = READ, bool channel = false){
    if(route == READ){
      if(!channel){
        // MAL Registers
        bool states[2] = {this -> toggleable(1,12,1,true), this -> toggleable(1,14,1,true)};
        if(states[0] && states[1]) throw MULTIPLE_SELECT;
        else if(states[0]) return HPL;
        else if(states[1]) return LOL;
        else if(!states[0] && !states[1]) return NONE;
      }else{
        // MAR Registers
        bool states[3] = {this -> toggleable(1,12,1,true), this -> toggleable(1,13,1,true), 
        this -> toggleable(1,15,1,true)};
        if(states[0] && states[1] && states[2]) throw MULTIPLE_SELECT;
        else if(states[0] == states[1] || states[0] == states[2] 
        || states[1] == states[2]) throw MULTIPLE_SELECT;
        else if(states[0]) return HPL;
        else if(states[1]) return HPR;
        else if(states[2]) return LOR;
        else if(!states[0] && !states[1] && !states[2]) return NONE;
      }
    }else{
      if(!channel){
        // MAL Registers
        if(route == LOL) this -> toggleable(1,14,1);
        else if(route == HPL) this -> toggleable(1,12,1);
        else throw VALUE;
      }else{
        // MAR Registers
        switch(route){
          case LOR: this -> toggleable(1,15,1); break; 
          case HPR: this -> toggleable(1,13,1); break;
          case HPL: this -> toggleable(1,12,0); break;
          default: throw VALUE; break; 
        }
      }
    }
   }
   /*!
     @breif          Determines the Output Common Mode for the High Power Dirvers.
     Default has the HP the same as the Full-Chip Common Mode(1), can be set to 
     1.25V(125), 1.5V(150), and 1.65V(165) is the Full-Chip is 0.9V, 1.5V if the 
     Full-Chip is 0.75V. Setting these values, use the numbers in parenthesis. As 
     a note, for the last vaule, just use the 165 if the Full-Chip is 0.75V. To 
     read back the setting, simply call the function, do not input anything.
     @param voltage  The voltage of the High Power Driver Outputs
     @return         Selected Voltage. Returned in the same format as set
   */
   //1,10,5-4
   int highOutputCommonMode(int voltage = 0){
    if(voltage == 0){
      voltage = this -> readData(1,10,2,4);
      switch(voltage){
        case 0: return 1; break;
        case 1: return 125; break;
        case 2: return 150; break;
        case 3: return 165; break;
      }
    }else{
      switch(voltage){
        case 1: voltage = 0; break;
        case 125: voltage = 1; break;
        case 150: voltage = 2; break;
        case 165: voltage = 3; break;
        default: throw VALUE; break;
      }
      this -> writeData(1,10,voltage,2,4);
    }
   }




////************************** INTERRUPTS **************************\\\\
   /*!
     @breif        Set the desired Interrupt to activate when a Headset is inserted
     into the audio jack. Default is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,7
   void headsetInsertion(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),7,true) != state) this -> toggleable(0,(int_ ? 49 : 48),7);
   }
   /*!
     @breif        Set the desired Interrupt to activate when a button press occurs
     on the Headphone line(s). Default is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,6
   void buttonPress(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),6,true) != state) this -> toggleable(0,(int_ ? 49 : 48),6);
   }
   /*!
     @breif        Set the desired Interrupt to activate when the DAC DRC(Dynamic
     Range Control) Signal Power exceeds either the Left or Right Channel Signal
     Threshold. This requires a read of Register 44 to distinguish which Channel.
     Default is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,5
   void analogOutDRCSignalThreshold(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),5,true) != state) this -> toggleable(0,(int_ ? 49 : 48),5);
   }
   /*!
     @breif        Generate an Interrupt when noise is detected by the AGC(Automatic
     Gain Control) for Left or Right Channel. This requires a read of Register 45 to
     distinguish which Channel. Default is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,4
   void autoGainControl(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),4,true) != state) this -> toggleable(0,(int_ ? 49 : 48),4);
   }
   /*!
     @breif        Set the desired Interrupt to trigger when an Over Current Condition
     has occured on either the Left or Right Channel. This requires a read of Register
     44 to distinguish which Channel. Default is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,3
   void headphoneOverCurrent(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),3,true) != state) this -> toggleable(0,(int_ ? 49 : 48),3);
   }
   /*!
     @breif        Either the ADC or DAC have a data overflow. Requires reading of
     Register 42 to distinguish which Converter. Default is 0, where an event is
     not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,2
   void analogOverflow(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),2,true) != state) this -> toggleable(0,(int_ ? 49 : 48),2);
   }
   /*!
     @breif        Generate an Interrupt when DC Measurement is available. Default
     is 0, where an event is not generated.
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,1
   void voltageMeasureReady(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),1,true) != state) this -> toggleable(0,(int_ ? 49 : 48),1);
   }
   /*!
     @breif        Default is 0, where the INT pin generates a single pulse of
     2ms(milliseconds), a 1 is a Pulse Train(Continuous Pulses) every 2ms. Requires
     the reading of Register 42, 44, or 45 to stop the Pulse Train
     @param  state Weather or not to generate an INT. true is generate, false is not
     @param  int_  Which Interrupt to choose. true is INT2, false is INT1.
   */
   //0,49/48,0
   void pulseControl(bool state, bool int_){
    if(this -> toggleable(0,(int_ ? 49 : 48),0,true) != state) this -> toggleable(0,(int_ ? 49 : 48),0);
   }






////************************** TOGGLEABLE **************************\\\\
//For all of these registers, a 1 is true, 0 is false, unless otherwise specified\\
   /*!
    @breif    The PLL Clock Range. Default is 0, Low PLL Clock Range. 1 is a high 
    Clock Range
    @return   State of this register
   */
   //0,4,6
   bool selectPLLRange(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,4,6,true);
    }
    this -> toggleable(0,4,6);
   }
   /*!
     @breif    Determines if a I2C General Call Address will be accepted. The default
     is a 0, where a General Call is ignored. 1 has the TLV3204 accept the General Call.
     @return   State of this register
   */
   //0,34,5
   bool generalCallI2C(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,34,5,true);
    }
    this -> toggleable(0,34,5);
   }
   /*!
     @breif    BCLK Direction. Toggled. 0 is an external BCLK(read), 1 is write BCLK
     to the controller
     @return   State of this register
   */
   //0,27,3
   bool bitClockDirection(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,27,3,true);
    }
    this -> toggleable(0,27,3);
   }
   /*!
     @breif    WCLK Direction. Toggled. 0 is an external WCLK(read), 1 is write WCLK
     to the controller
     @return   State of this register
   */
   //0,27,2
   bool wordClockDirection(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,27,2,true);
    }
    this -> toggleable(0,27,2);
   }
   /*!
     @breif    Base is a 0, where DOUT is not high impedance while Audio Interface is
     active, 1 is High Impedance after data has been transferred
     @return   State of this register
   */
   //0,27,0
   bool dataOutImpendanceControl(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,27,0,true);
    }
    this -> toggleable(0,27,0);
   }
   /*!
     @breif    Default is 0(no Loopback), 1 has Audio Data In route to Audio Data Out,
     which only works when WCLK is a configured input
     @return   State of this register
   */
   //0,29,5
   bool loopbackControlAudio(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,29,5,true);
    }
    this -> toggleable(0,29,5);
   }
   /*!
     @breif    Default is 0(no Loopback), 1 has Stereo ADC output routed to Stereo
     DAC input.
     @return   State of this register
   */
   //0,29,4
   bool loopbackControlStereo(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,29,4,true);
    }
    this -> toggleable(0,29,4);
   }
   /*!
     @breif    On first call, the Audio Bit Clock polarity is then flipped
     @return   State of this register
   */
   //0,29,3
   bool audioBitClockPolarity(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,29,3,true);
    }
    this -> toggleable(0,29,3);
   }
   /*!
     @breif    The BCLK and WCLK Power Control. A 0 is where they power down with
     the Codec Power, a 1 signifies that they are used in clock generation,
     regardless of the state of the Codec.
     @return   State of this register
   */
   //0,29,2
   bool bitAndWordClockPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,29,2,true);
    }
    this -> toggleable(0,29,2);
   }


   /*!
     @breif    Which Bit Clock to use: Primary(0) or Secondary(1) for Audio
     Interface and Clocking. Pin is set by secondaryBitClock().
     @return   State of this register
   */
   //0,32,3
   bool bitClockSource(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,32,3,true);
    }
    this -> toggleable(0,32,3);
   }
   /*!
     @breif    Which Word Clock to use: Primary(0) or Secondary(1) for Audio
     Interface and Clocking. Pin is set by secondaryWordClock().
     @return   State of this register
   */
   //0,32,2
   bool wordClockSource(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,32,2,true);
    }
    this -> toggleable(0,32,2);
   }
   /*!
     @breif    What to set the ADC Word Clock to. 0 is ADC Word Clock is the
     same as the DAC Word Clock, a 1 is to use the Secondary ADC Word Clock.
     Pin is set by analogInWordClock().
     @return   State 0f this register
   */
   //0,32,1
   bool analogInWordClockSource(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,32,1,true);
    }
    this -> toggleable(0,32,1);
   }
   /*!
     @breif    Determines the pin used from the Audio Data In. Default is 0,
     where DIN is the Duido Data In(Of Audio Interface) or 1, which is the
     pin selected for use by the Secondary Data In. Pin is set by
     secondaryDataIn().
     @return    State of this register
   */
   //0,32,0
   bool audioDataInSource(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,32,0,true);
    }
    this -> toggleable(0,32,0);
   }
   /*!
     @breif    Determines where the BCLK is to be outputted from. The default
     is 0, the Generated Primary Bit Clock, and 1 is the Secondary Bit Clock
     Input. Pin is selected by secondaryBitClock().
     @return   State of this register
   */
   //0,33,7
   bool bitClockOutput(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,33,7,true);
    }
    this -> toggleable(0,33,7);
   }
   /*!
     @breif    The Secondary Bit Clock. Default is 0, with the Secondary Bit
     Clock equal to BCLK Input, and a 1 is Secondary Bit Clock is equal to
     the Generated Primary Bit Clock
     @return   State of this register
   */
   //0,33,6
   bool secondaryBitClockOutput(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,33,6,true);
    }
    this -> toggleable(0,33,6);
   }


   /*!
     @breif    Primary Data Out Output Control. Default is 0, with DOUT being
     the Data Output from Serial Interface, and a 1 is the Secondary Data Input
     acting as a Loopback
     @return   State of this register
   */
   //0,33,1
   bool primaryDataOut(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,33,1,true);
    }
    this -> toggleable(0,33,1);
   }
   /*!
     @brief    Secondary Data Out Output Control. Default is 0, with the
     Secondary Data Output equal to the DIN Input, acting as a Loopback. A 1 is
     the Secondary Data Output is the Data Output from Serial Interface.
     @return   State of this register
   */
   //0,33,0
   bool secondaryDataOut(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,33,0,true);
    }
    this -> toggleable(0,33,0);
   }


   /*!
     @breif    Controls the Right Modulator Output. Default is 0, when the Right
     DAC Channel is powered down, the data is 0. A 1 has the data inverted of Left
     DAC Modulator Output. It can be used when differential Mono Output is used
     @return   State of this register
   */
   //0,64,7
   bool rightModulatorOutput(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,64,7,true);
    }
    this -> toggleable(0,64,7);
   }
   /*!
     @breif    Left DAC Channel Mute Control. Default is 1; Left DAC is muted. 0
     unmutes the Left DAC Channel
     @return   State of this register
   */
   //0,64,3
   bool muteLeft(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,64,3,true);
    }
    this -> toggleable(0,64,3);
   }
   /*!
     @breif    Right DAC Channel Mute Control. Default is 1; Right DAC is muted. 0
     unmutes the Right DAC Channel
     @return   State of this register
   */
   //0,64,2
   bool muteRight(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,64,2,true);
    }
    this -> toggleable(0,64,2);
   }
   /*!
     @breif   Left DAC Channel Power Control. Default is 0, where the Left DAC is 
     powered down. 1 powers it up.
     @return  State of this register
   */
   //0,63,7
   bool leftDACPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,63,7,true);
    }
    this -> toggleable(0,63,7);
   }
   /*!
     @breif   Right DAC Channel Power Control. Default is 0, where the Right DAC is 
     powered down. 1 powers it up.
     @return  State of this register
   */
   //0,63,6
   bool rightDACPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,63,6,true);
    }
    this -> toggleable(0,63,6);
   }


   /*!
     @breif    Left Channel DRC Status. Disabled before first call. As a note: DRC
     is only active if a PRB has been selected that supports DRC.
     @return   State of this register
   */
   //0,68,6
   bool leftDRCControl(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,68,6,true);
    }
    this -> toggleable(0,68,6);
   }
   /*!
     @breif    Right Channel DRC Status. Disabled before first call. As a note:
     DRC is only active if a PRB has been selected that supports DRC.
     @return   State of this register
   */
   //0,68,5
   bool rightDRCControl(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,68,5,true);
    }
    this -> toggleable(0,68,5);
   }


   /*!
     @breif    Left Channel ADC Power. Default is 0: off. 1 powers up
     @return   State of this register
   */
   //0,81,7
   bool leftADCPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,81,7,true);
    }
    this -> toggleable(0,81,7);
   }
   /*!
     @breif    Left Channel Digital Microphone Power Control. Default is 0,
     where the Left Channel ADC is not configured for a Digital Microphone. 1 is
     the Left Channel ADC is configured for a Digital Microphone
     @return   State of this register
   */
   //0,81,3
   bool leftDigitalMicrophone(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,81,3,true);
    }
    this -> toggleable(0,81,3);
   }
   /*!
     @breif    Right Channel ADC Power. Default is 0: off. 1 powers up
     @return   State of this register
   */
   //0,81,6
   bool rightADCPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,81,6,true);
    }
    this -> toggleable(0,81,6);
   }
   /*!
     @breif    Right Channel Digital Microphone Power Control. Default is 0,
     where the Right Channel ADC is not configured for a Digital Microphone. 1 is
     the Right Channel ADC is configured for a Digital Microphone
     @return   State of this register
   */
   //0,81,2
   bool rightDigitalMicrophone(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,81,2,true);
    }
    this -> toggleable(0,81,2);
   }
   /*!
     @breif    Left ADC Channel Mute. Default is 1, where Left ADC Channel is
     muted, 0 to unmute
     @return   State of this register
   */
   //0,82,7
   bool leftADCMute(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,82,7,true);
    }
    this -> toggleable(0,82,7);
   }
   /*!
     @breif    Right ADC Channel Mute. Default is 1, where Right ADC Channel is
     muted, 0 to unmute
     @return   State of this register
   */
   //0,82,3
   bool rightADCMute(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(0,82,3,true);
    }
    this -> toggleable(0,82,3);
   }




   /*!
     @breif    Left DAC routing control. Default is 0, where Left DAC is routed to
     HPL with a Class-AB Driver. 1 is for a Class-D Driver
     @return   State of this register
   */
   //1,3,7-6
   bool leftDACRouting(){
    int data = this -> readData(1,3,2,6);
    if(readToggle){
      !readToggle;
      if(data == 0b11) return true;
      else if(data == 0b00) return false;
    }
    this -> writeData(1,3,!data,2,6);
   }
   /*!
     @breif    Right DAC routing control. Default is 0, where Right DAC is routed to
     HPL with a Class-AB Driver. 1 is for a Class-D Driver
     @return   State of this register
   */
   //1,4,7-6
   bool rightDACRouting(){
    int data = this -> readData(1,4,2,6);
    if(readToggle){
      !readToggle;
      if(data == 0b11) return true;
      else if(data == 0b00) return false;
    }
    this -> writeData(1,4,!data,2,6);
   }


   /*!
     @breif    The AVDD connection. Default is 0, where AVD is weakly connected
     to DVDD. Use when DVDD is powered, AVDD LDO is powered down and AVDD is
     not externally powered. 1 disables this connection
     @return   State of this register
   */
   //1,1,3
   bool analogConnection(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,1,3,true);
    }
    this -> toggleable(1,1,3);
   }
   /*!
     @breif    Analog Block Power. Default is 1, where the Analog Blocks are
     disabled. 0 enables them.
     @return   State of this register
   */
   //1,2,3
   bool analogBlockPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,2,3,true);
    }
    this -> toggleable(1,2,3);
   }
   /*!
     @breif    Analog Supply Low Drop-Out Power control. Default is 0, where AVDD
     LDO is powered down. 1 Powers AVDD LDO up.
     @return   State of this register
   */
   //1,2,0
   bool analogLDOPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,2,0,true);
    }
    this -> toggleable(1,2,0);
   }


   /*!
     @breif    Controls the HPL(High Power Left) power. Default is 0, powered down,
     1 to power up.
     @return   State of this register
   */
   //1,9,5
   bool highLeftPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,5,true);
    }
    this -> toggleable(1,9,5);
   }
   /*!
     @breif    Controls the HPR(High Power Right) power. Default is 0, powered
     down, 1 to power up.
     @return   State of this register
   */
   //1,9,4
   bool highRightPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,4,true);
    }
    this -> toggleable(1,9,4);
   }
   /*!
     @breif    Controls the LOL(Low Output Left) power. Default is 0, powered down,
     1 to power up.
     @return   State of this register
   */
   //1,9,3
   bool lowLeftPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,3,true);
    }
    this -> toggleable(1,9,3);
   }
   /*!
     @breif    Controls the LOR(Low Output Right) power. Default is 0, powered down,
     1 to power up.
     @return   State of this register
   */
   //1,9,2
   bool lowRightPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,2,true);
    }
    this -> toggleable(1,9,2);
   }
   /*!
     @breif    Controls the MAL(Mixer Amplifier Left) power. Default is 0, powered
     down, 1 to power up.
     @return   State of this register
   */
   //1,9,1
   bool mixerAmplifierLeftPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,1,true);
    }
    this -> toggleable(1,9,1);
   }
   /*!
     @breif    Controls the MAR(Mixer Amplifier Right) power. Default is 0, powered
     down, 1 to power up.
     @return   State of this register
   */
   //1,9,0
   bool mixerAmplifierRightPower(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,9,0,true);
    }
    this -> toggleable(1,9,0);
   }


   /*!
     @breif    Full Chip Common Mode voltage. Default is 0, 0.9V, 1 is 0.75V
     @return   State of this register
   */
   //1,10,6
   bool chipCommonMode(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,10,6,true);
    }
    this -> toggleable(1,10,6);
   }
   /*!
     @breif    Output Common Mode for LOL and LOR. Default is 0, where LOL and LOR
     have the same Common Mode as Full-Chip. 1 has them at 1.65V and powered by LDOIN
     @return   State of this register
   */
   //1,10,3
   bool lowOutputCommonMode(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,10,3,true);
    }
    this -> toggleable(1,10,3);
   }
   /*!
     @breif    Output of HPL and HPR Power Source. Default is 0, where HPL and HPR
     are powered with the AVDD Supply, 1 is powered by LDOIN.
     @return   State of this register
   */
   //1,10,1
   bool highOutputPowerSource(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,10,1,true);
    }
    this -> toggleable(1,10,1);
   }
   /*!
     @breif    LDOIN Voltage Range. Depends on the status of highOutputPowerSource.
     Default is 0, where LDOIN input range is 1.5V to 1.95V. 1 has a range of 1.8V
     to 3.6V.
     @return   State of this register
   */
   //1,10,0
   bool inputRangeLDOIN(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,10,0,true);
    }
    this -> toggleable(1,10,0);
   }


   /*!
     @breif    Over Current Detection. Default is 1, where Over Current detection is
     enabled for HPL and HPR. 0 disables it.
     @return   State of this register
   */
   //1,11,4
   bool overCurrentHigh(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,11,4,true);
    }
    this -> toggleable(1,11,4);
   }
   /*!
     @breif    What to do in the event of an Over Current Condition. Default is 0,
     where the output current will be limited. 1 powers the Output Driver down.
     @return   State of this register
   */
   //1,11,0
   bool overCurrentAction(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,11,0,true);
    }
    this -> toggleable(1,11,0);
   }

   /*!
     @breif    In 1 LEft Routing. Default is 0, IN1L is not routed to HPL. 1 is
     IN1L is routed to HPL
     @return   State of this register
   */
   //1,12,2
   bool in1LeftRoute(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,12,2,true);
    }
    this -> toggleable(1,12,2);
   }
   /*!
     @breif    In 1 Right Routing. Default is 0, IN1R is not routed to HPR. 1 
     is IN1R is routed to HPR
     @return   State of this register
   */
   //1,13,2
   bool in1RightRoute(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,13,2,true);
    }
    this -> toggleable(1,13,2);
   }
   

////************************* RECONSTRUCTION FILTER *********************\\\\
   
   /*!
     @breif    Determines the routing of the Left Channel DAC Reconstruction 
     Filter Positive Terminal. Default is 0, where the Filter is not routed to 
     HPL. 1 routes it to HPL.
     @return   State of this register
   */
   //1,12,3
   bool leftReconPos(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,12,3,true);
    }
    this -> toggleable(1,12,3);
   }
   /*!
     @breif    Determines the routing of the Left Channel DAC Reconstruction 
     Filter Negative Terminal. Default is 0, where the Filter is not routed to 
     HPR. 1 routes it to HPR.
     @return   State of this register
   */
   //1,13,4
   bool leftReconNeg(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,13,4,true);
    }
    this -> toggleable(1,13,4);
   }
   /*!
     @breif    Determines the routing of the Left Channel DAC Reconstruction 
     Filter Output. Default is 0, where the Filter is not routed to LOL
     1 routes it to LOL.
     @return   State of this register
   */
   //1,14,3
   bool leftRecon(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,14,3,true);
    }
    this -> toggleable(1,14,3);
   }

   /*!
     @breif    Determines the routing of the Right Channel DAC Reconstruction 
     Filter Positive Terminal. Default is 0, where the Filter is not routed to 
     HPR. 1 routes it to HPR.
     @return   State of this register
   */
   //1,13,3
   bool rightReconPos(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,13,3,true);
    }
    this -> toggleable(1,13,3);
   }
   /*!
     @breif    Determines the routing of the Right Channel DAC Reconstruction 
     Filter Negative Terminal. Default is 0, where the Filter is not routed to 
     LOL. 1 routes it to LOL.
     @return   State of this register
   */
   //1,14,4
   bool rightReconNeg(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,14,4,true);
    }
    this -> toggleable(1,14,4);
   }
   /*!
     @breif    Determines the routing of the Left Channel DAC Reconstruction 
     Filter Output. Default is 0, where the Filter is not routed to LOR
     1 routes it to LOR.
     @return   State of this register
   */
   //1,15,3
   bool rightRecon(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(1,14,3,true);
    }
    this -> toggleable(1,15,3);
   }
////************************** ADAPTIVE FILTER **************************\\\\
   /*!
     @breif    Adaptive Filtering Control for ADC. Default is 0, where Adaptive
     Filtering is disabled, 1 to enable
     @return   State of this register
   */
   //8,1,2
   bool adaptiveFilteringADC(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(8,1,2,true);
    }
    this -> toggleable(8,1,2);
   }
   /*!
     @breif    Adaptive Filter Buffer Switch Control. Default is 0, where the ADC
     Coefficient Buffers will not be switched at next frame boundary. 1 has them
     switch at the next frame boundary, if in adaptive filtering mode. This will self-
     clear on switching.
     @return   State of this register
   */
   //8,1,0
   bool adaptiveFilterBufferADC(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(8,1,0,true);
    }
    this -> toggleable(8,1,0);
   }
   /*!
     @breif    Adaptive Filtering Control for DAC. Default is 0, where Adaptive
     Filtering is disabled, 1 to enable
     @return   State of this register
   */
   //44,1,2
   bool adaptiveFilteringDAC(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(44,1,2,true);
    }
    this -> toggleable(44,1,2);
   }
   /*!
     @breif    Adaptive Filter Buffer Switch Control. Default is 0, where the DAC
     Coefficient Buffers will not be switched at next frame boundary. 1 has them
     switch at the next frame boundary, if in adaptive filtering mode. This will self-
     clear on switching.
     @return   State of this register
   */
   //44,1,0
   bool adaptiveFilterBufferDAC(){
    if(readToggle){
      !readToggle;
      return this -> toggleable(44,1,0,true);
    }
    this -> toggleable(44,1,0);
   }
};