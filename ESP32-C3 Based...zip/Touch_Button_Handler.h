#include <Adafruit_ILI9341.h>
#include <Adafruit_FT6206.h>
class Touch_Button{
  public:
    /*!
      @breif  Used only to pass in the objects for th display
      @param  screen  The ILI9341 Object
      @param  touch   The FT6206 Object
    */
    Touch_Button::Touch_Button(Adafruit_ILI9341 screen, Adafruit_FT6206 touch){
      tft = screen;
      tp = touch;
    }

  private:
    Adafruit_ILI9341 tft;// Screen for other classes
    Adafruit_FT6206 tp;// Touch for other classes
}

class Button{
  /*
  Formating for the TP_RST
    byte data = beginComm((pin<8:0x02?0x03),0,DEVICE_ADDRESS[1],true);
    byte tempData[2] = {
      //Used for the XOR
      ((0b0 >> (pin < 8 : pin ? pin - 8)) + 1) >> (8 - (pin < 8 : pin ? pin - 8)),
      0// Result for XORing the data
    };
    //XORing the data
    tempData[2] = data ^ tempData[1];
    //SEND IT!
    beginComm((pin<8:0x02?0x03),tempData[2],DEVICE_ADDRESS[1]);

  Formating for the TP_INT
    byte data = beginComm(pin<8?0x00:0x01,0,DEVICE_ADDRESS[1],true);
    byte tempData[2] = {
      ((0b0 >> (pin < 8 ? pin : pin - 8)) + 1) >> 8 - (pin < 8 ? pin : pin - 8),0
    }
    tempData[1] = (data | tempData[0]) ^ data;// OR then XOR
    tempData[1] = tempData[1] << (8 - (pin < 8 ? pin : pin - 8));// Remove Leading zeros
    return tempData[1] == 1;

    byte beginComm(byte reg, byte data, byte addr, bool read_ = false){
      Wire.beginTransmission(addr);
      Wire.write(0);// Declaring that it will be a write
      Wire.write(reg);
      if(read_){
        Wire.beginTransmission(addr);
        Wire.write(1);// Read 
        data[0] = Wire.read();
        return data;
      }
      Wire.write(data[0]);
      while(Wire.read() == 1);// Wait for slave ACK
      Wire.write(data[1]);
      Wire.endTransmission();
    }
  */
  public:
    /*!
      @breif  Initalizes the Button object, where the points of a two-point 
      rectangle reside
      @param  x_0  The first point X-Coordinate
      @param  y_0  The first point Y-Coordinate
      @param  x    The second point X-Coordinate
      @param  y    The second point Y-Coordinate 
    */
    Button::Button(int8_t x_0, int16_t y_0, int8_t x, int16_t y){
      buttonX_0 = x_0;
      buttonY_0 = y_0;
      buttonX = x;
      buttonY = y;
    }
    /*!
      @breif  The color of the button's text and fill
      @param  r_F  The Red value of the color for fill
      @param  g_F  The Green value of the color for fill
      @param  b_F  The Blue value of the color for fill
      @param  r_T  The Red value of the color for text
      @param  g_T  The Green value of the color for text
      @param  b_T  The Blue value of the color for text
    */
    void setColor(byte r_F, byte g_F, byte b_F, byte r_T, byte g_T, byte b_T){
      buttonFill = ((r_F & 0b11111000) << 8) + ((g_F & 0b11111100) << 3) + (b_F >> 3);
      buttonText = ((r_T & 0b11111000) << 8) + ((g_T & 0b11111100) << 3) + (b_T >> 3)
    }
    /*!
      @breif  What to display inside the button.
      @param  text  The text to set.
      @param  size  The size of the text from the GFX Font. Default is 1
    */
    void setText(String text, byte size = 1){
      buttonText = text;
      buttonTextSize = size;
    }
    /*!
      @breif  Specifically used for creating the song info buttons
      @param  name  The given name of the song
      @param  position  The position of the button from an array in main that holds the 
      position of the order added of each song. The x and y are calculated here
      @param  time  The total recording lenght, in milliseconds
      @param  artist  The name of the artist of the song. Optional.
    */
    void songButton(String name, int16_t position, int32_t time, String artist = "null"){
      songName = name;
      songArtist = artist;
      positionOfSong = position;
      songLength = time;
    }

    /*!
      @breif  Called to put the button on the display or remove it from the display
      @param  buttonDisplayState  Returns the state of the button, if it is on the display or not. true if it is, false if
      it is not.
    */
    void display(){
      tft.fillRect(buttonX_0, buttonY_0, buttonX_0 - buttonX, buttonY_0 - buttonY, buttonFill);
      tft.setTextSize(buttonTextSize);
      tft.setTextColor(buttonTextColor);
      int16_t x, y = (buttonY_0 - buttonY - TEXT_HEIGHT * buttonTextSize) / 2;;
      if(centerText) x = (buttonX_0 - buttonX - sizeof(buttonText) * TEXT_WIDTH * buttonTextSize) / 2;
      if(textSide) x = buttonX_0 + (textOffset > 0 ? textOffset : 1);
      else x = buttonX_0 - buttonX - sizeof(buttonText) * TEXT_WIDTH * buttonTextSize - (textOffset > 0 ? textOffset : 1);
      tft.setCursor(x,y);
      tft.print(buttonText);
    }
    /*!
      @breif  The position of the text in the drawn button
      @param  center  Weather or not to center the text. true to center, false to use a side
      @param  side  Which side to have the text on. true is left, false is right. 
      @param  offset  The offset from the side. Default is 1 pixel. It will always be one pixel
      from the edge of the rectangle
    */
    void textPosition(bool center, bool side, byte offset = 1){
      centerText = center; textSide = side;
      textOffset = offset;
    }
  private:
    static const int TEXT_HEIGHT = 16;// In Pixels
    static const int TEXT_WIDTH = 10;// In Pixels
    uint16_t buttonFill;
    uint16_t buttonText;
    int8_t buttonX_0, buttonX;
    int16_t buttonY_0, buttonY;
    String buttonText;
    byte buttonTextSize;
    bool centerText, textSide;
    byte textOffset;
    String songName, songArtist;
    int16_t positionOfSong;
    int32_t songLength;
}