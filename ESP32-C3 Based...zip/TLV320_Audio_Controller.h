#ifndef TLV320ALC3204_LIBRARY
#define TLV320AIC3204_LIBRARY

#include <Wire.h>


class TLV3204{
public:
////************************** METHODS **************************\\\\
  TLV3204_Controller();
  void TLV3204(int dataPin, int clockPin);
  //0,1,0
  void softReset();
  void readToggleRegister();
  //1,123,2-0
  void refPowerUp(int time, bool type);
////************************** CLOCK SETTINGS **************************\\\\
  //rou 0,5,6-4
  //R 0,5,3-0
  //J 0,6,5-0
  //D 0,7(5-0)-8(7-0)
  int clockDividerPLL(int rou, int R, int J, int D);
  //0,4,3-2
  int inputClockPLL(KEYWORDS clockSource);
  //0,4,1-0
  int codecClockIn(KEYWORDS clockSource);
  //Power 0,11,7(DAC), 0,18,7(ADC)
  //DAC 0,11,6-0
  //ADC 0,18,6-0
  int clockSettingN(int analogIn, int analogOut);
  //Power 0,12,7(DAC), 0,19,7(ADC)
  //DAC 0,12,6-0
  //ADC 0,19,6-0
  int clockSettingM(int analogIn, int analogOut);
  //Power 0,26,7
  //0,26,6-0
  int clockOutM(int value = 130);
  //0,28,7-0
  void dataInOffset(int offset);
  //Power 0,30,7
  //0,30,6-0
  void bitClockNDivider(int value);
////************************** MULTIPLEXERS **************************\\\\
  //0,25,2-0
  void CDIVClock(KEYWORDS clockSource);
  //0,29,1-0
  void BDIVClock(KEYWORDS clockSource);
  //0,31,6-5
  int secondaryBitClock(KEYWORDS pin);
  //0,31,4-3
  int secondaryWordClock(KEYWORDS pin);
  //0,31,2-1
  int analogInWordClock(KEYWORDS pin);
  //0,31,0
  int secondaryDataIn(KEYWORDS pin);
////************************** AUDIO SETTINGS **************************\\\\
  //0,13(1-0)-14(7-0)
  int analogOutOversampling(int value = 0);
  //0,20,7-0
  int analogInOversampling(int value = 0);
  //Interface 0,27,7-6
  //Word Length 0,27,5-4
  void audioInterface(KEYWORDS protocal, int wordLength);
  //0,60,4-0
  int analogOutSignalProcessingBlock(int block = 0);
  //0,61,4-0
  int analogInSignalProcessingBlock(int block = 0);
////**************** MULTIFUNCTION PIN CONFIGURATION *****************\\\\
  //0,52,5-0
  int generalInputOutputMFP5(KEYWORDS function);
  bool stateGPIO();
  void outputGPIO(bool state);
  //0,53,4-0
  int dataOutMuxControl(KEYWORDS function);
  void outputDOUT(bool state);
  //0,54,2-0
  int dataInAudioControl(KEYWORDS function);
  bool stateDIN();
  //0,55,4-0
  int dataInSPIControl(KEYWORDS function);
  void outputDIN(bool state);
  //0,56,2-0
  int clockSPIControl(KEYWORDS function);
  bool stateSCLK();
////************************** DAC SETUP/CONTROL **************************\\\\
  //0,63,5-4,3-2
  int channelDACSetup(bool channel, int path = 4);
  //0,63,1-0
  int softStepDAC(int setting = 3);
  //0,64,6-4
  int autoMuteDAC(int consecInput = -1);
  //0,64,1-0
  int masterVolumeDAC(int setting = 3);
  //0,65
  int leftChannelVolume(int volume = -640);
  //0,66
  int rightChannelVolume(int volume = -640);
////************************** HEADSET **************************\\\\
  //0,67,4-2
  int headsetDetectDebounce(int time = 0);
  //0,67,1-0
  int headsetButtonDebounce(int time = 255);
  //0,67,6-5
  int headsetType();
  //1,20,7-6
  int softRoutingStepTime(int time = 255);
  //1,20,5-2,1-0
  int headphoneRampPower(int rampPower = 0, int resistance = 0);
////************************ VOLUME CONTROL ***********************\\\\
  /*
  MAR: 1,25,5-0
  MAL: 1,24,5-0
  IN1R to HPR: 1,23,6-0
  IN1L to HPL: 1,22,6-0
  */
  void volumeControl(VOLUME_CONTROL_SELECTOR route, int volume, bool mute = false);
////********************** MICROPHONE CONTROL *********************\\\\
  //TODO: Cry, then implement the Microphone control
////****************** DYNAMIC RANGE CONTROL(DRC) ******************\\\\
  //0,68,4-2
  int thresholdDRC(int threshold = 0);
  //0,68,1-0
  int hysteresisDRC(int value = 4)
  //0,69,4-3
  int holdTimeDRC(int wordClocks = 16);
  //0,70,7-4
  int attackRateDRC(int attackRate = 16);
  //0,70,3-0
  int decayRateDRC(int decayRate = 16)




////********* ANALOG TO DIGITAL CONVERTER SETTINGS(ADC) ************\\\\
  //0,81,5-4
  int digitalMicrophoneInputConfig(int input = 3);
  //0,81,1-0
  int softStepADC(int setting = 3);
  //0,82,6-4
  int leftFineGain(int gain = 1);
  //0,82,2-0
  int rightFineGain(int gain = 1);
  //0,83,6-0
  int leftADCVolume(int volume = 255);
  //0,84,6-0
  int rightADCVolume(int volume = 255);
  //0,85
  int phaseCompensationADC(int phase, int decimationFilter, 
  bool channel = false, bool enable = false);
////***************** AUTOMATIC GAIN CONTROL(AGC) ********************\\\\
  bool channelSelectorAGC();
  bool readAGC();
  //0,94,6-4
  //0,86,6-4
  int targetLevelAGC(int level = 0);
  //Gain 0,94,1-0
  //Setting 0,95,7-6
  //Gain 0,86,1-0
  //Setting 0,87,7-6
  int hysteresisAGC(int gain = 0, int setting = 0);
  //Right Signal Debounce 0,100,3-0
  //Left Signal Debounce 0,92,3-0
  //Right Noise Debounce 0,99,4-0
  //Left Noise Debounce 0,91,4-0
  //Right Noise Threshold, 0,95,5-1
  //Left Noise Threshold 0,87,5-1
  int noiseSettingAGC(int signalDebounce = 0, int noiseThreshold = 0, 
  int noiseDebounce = 0);
  //Right Max Gain 0,96,6-0
  //Left Max Gain 0,88,6-0
  int maxGainAGC(int gain = 0);
  //0,97
  //0,89
  int attackAGC(int time = 0, int scale = 0);
  //0,98
  //0,90
  int decayAGC(int time = 0, int scale = 0);


////********************** ADC POWERTUNE *****************************\\\\
  //1,71,5-0
  int analogInputPowerTime(int time);
  //1,61,0-7
  int analogInPowerTuneConfig(KEYWORDS ptm = READ);
////************************ BEEP GENERATOR ************************\\\\
  //Right 0,72,5-0
  //Left 0,71,5-0
  bool beepVolumeControl(int left, int right, int masterSetting);
  //Sin: 76-77
  //Cos: 78-79
  float beepFrequency(float freq = 0);
  //0,73-75
  int beepTime(int time = -1);
////************************ DC MEASUREMENT ************************\\\\
  //0,102,5
  bool powerMeasureFilter();
  //0,103,5
  bool powerMeasureIIR();
  //0,102,4-0
  int powerMeasureD(int D = 0);
  //0,103,4-0
  int powerMeasureIIR(int time = 25);
  //Left: 0, 104(23:16)-106(7:0)
  //Right: 0, 107(23:16)-109(7:0)
  float powerMeasurement(bool channel = false);
  //1,2,7-6
  int digitalLDOControl(int output = 0);
  //1,2,5-4
  int analogLDOControl(int output = 0);
  //1,3,4-2
  int leftDACPTM(int mode = 0);
  //1,4,4-2
  int rightDACPTM(int mode = 0);
  //1,11,1-3
  int overCurrentDebounce(int debounce);
  /*
  Mute LOR: 1,19,6
  Mute LOL: 1,18,6
  Mute HPR: 1,17,6
  Mute HPL: 1,16,6
  LOR Driver Gain: 1,19,5-0
  LOL Driver Gain: 1,18,5-0
  HPR Driver Gain: 1,17,5-0
  HPL Driver Gain: 1,16,5-0
  */
  void driverGainAndMute(int driver, bool mute, int gain);
  //1,12,1
  int mixerAmplifierRoute(KEYWORDS route = READ, bool channel = false);
  //1,10,5-4
  int highOutputCommonMode(int voltage = 0);
////************************** INTERRUPTS **************************\\\\
  //0,49/48,7
  bool headsetInsertion(bool state, bool int_);
  //0,49/48,6
  bool buttonPress(bool state, bool int_);
  //0,49/48,5
  bool analogOutDRCSignalThreshold(bool state, bool int_);
  //0,49/48,4
  bool autoGainControl(bool state, bool int_);
  //0,49/48,3
  bool headphoneOverCurrent(bool state, bool int_);
  //0,49/48,2
  bool analogOverflow(bool state, bool int_);
  //0,49/48,1
  bool voltageMeasureReady(bool state, bool int_);
  //0,49/48,0
  bool pulseControl(bool state, bool int_);
////************************** TOGGLEABLE **************************\\\\
//For all of these registers, a 1 is true, 0 is false, unless otherwise specified\\
  //0,4,6
  bool selectPLLRange();
  //0,34,5
  bool generalCallI2C();
  //0,27,3
  bool bitClockDirection();
  //0,27,2
  bool wordClockDirection();
  //0,27,0
  bool dataOutImpendanceControl();
  //0,29,5
  bool loopbackControlAudio();
  //0,29,4
  bool loopbackControlStereo();
  //0,29,3
  bool audioBitClockPolarity();
  //0,29,2
  bool bitAndWordClockPower();
  //0,32,3
  bool bitClockSource();
  //0,32,2
  bool wordClockSource();
  //0,32,1
  bool analogInWordClockSource();
  //0,32,0
  bool audioDataInSource();
  //0,33,7
  bool bitClockOutput();
  //0,33,6
  bool secondaryBitClockOutput();
  //0,33,1
  bool primaryDataOut();
  //0,33,0
  bool secondaryDataOut();
  //0,64,7
  bool rightModulatorOutput();
  //0,64,3
  bool muteLeft();
  //0,64,2
  bool muteRight();
  //0,63,7
  bool leftDACPower();
  //0,63,6
  bool rightDACPower();
  //0,68,6
  bool leftDRCControl();
  //0,68,5
  bool rightDRCControl();
  //0,81,7
  bool leftADCPower();
  //0,81,3
  bool leftDigitalMicrophone();
  //0,81,6
  bool rightADCPower();
  //0,81,2
  bool rightDigitalMicrophone();
  //0,82,7
  bool leftADCMute();
  //0,82,3
  bool rightADCMute();
  //1,3,7-6
  bool leftDACRouting();
  //1,4,7-6
  bool rightDACRouting();
  //1,1,3
  bool analogConnection();
  //1,2,3
  bool analogBlockPower();
  //1,2,0
  bool analogLDOPower();
  //1,9,5
  bool highLeftPower();
  //1,9,4
  bool highRightPower();
  //1,9,3
  bool lowLeftPower();
  //1,9,2
  bool lowRightPower();
  //1,9,1
  bool mixerAmplifierLeftPower();
  //1,9,0
  bool mixerAmplifierRightPower();
  //1,10,6
  bool chipCommonMode();
  //1,10,3
  bool lowOutputCommonMode();
  //1,10,1
  bool highOutputPowerSource();
  //1,10,0
  bool inputRangeLDOIN();
  //1,11,4
  bool overCurrentHigh();
  //1,11,0
  bool overCurrentAction();
  //1,12,2
  bool in1LeftRoute();
  //1,13,2
  bool in1RightRoute();
////************************* RECONSTRUCTION FILTER *********************\\\\
  //1,12,3
  bool leftReconPos();
  //1,13,4
  bool leftReconNeg();
  //1,14,3
  bool leftRecon();
  //1,13,3
  bool rightReconPos();
  //1,14,4
  bool rightReconNeg();
  //1,15,3
  bool rightRecon();
////************************** ADAPTIVE FILTER **************************\\\\
  //8,1,2
  bool adaptiveFilteringADC();
  //8,1,0
  bool adaptiveFilterBufferADC();
  //44,1,2
  bool adaptiveFilteringDAC();
  //44,1,0
  bool adaptiveFilterBufferDAC();
  
private:
  static const int DEVICE_ADDRESS = 0x20;// 0011000 Bin, 32 Dec
  static const int SCL_PULSE = 25;// TODO: Change to the time of a SCL Pulse
  bool readToggle = false;
  bool selectedChannelACG = true, readAGC = false;
  void writeData(int pageNum, int regNum, int data, int length = 8, int startBit = 0);
  void writeData(int pageNum, int regNum[], int  data, int length, int startBit = 0);
  int readData(int pageNum, int regNum, int length, int startBit = 0);
  int readData(int pageNum, int regNum[], int length, int startBit = 0);
  bool toggleable(int pageNum, int regNum, int start, bool read_ = false);
  bool timeOut(bool beginTransmission = false);
};

#endif